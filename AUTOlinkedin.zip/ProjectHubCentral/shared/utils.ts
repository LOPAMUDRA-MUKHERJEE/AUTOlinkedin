/**
 * Utility functions shared between client and server
 */

/**
 * Extract potential username and email from project files
 * Useful for suggesting author information for LinkedIn posts
 */
export function extractUsernameAndEmail(files: { path: string; content: string }[]): {
  username?: string;
  email?: string;
} {
  let username: string | undefined;
  let email: string | undefined;

  // Look for package.json for author information
  const packageJson = files.find(file => file.path.endsWith('package.json'));
  if (packageJson) {
    try {
      const packageData = JSON.parse(packageJson.content);
      
      // Try to get author information
      if (packageData.author) {
        if (typeof packageData.author === 'string') {
          // Parse author field if it's in the format "Name <email>"
          const authorMatch = packageData.author.match(/^(.*?)(?: <(.+@.+)>)?$/);
          if (authorMatch) {
            username = authorMatch[1];
            email = authorMatch[2];
          }
        } else if (typeof packageData.author === 'object') {
          username = packageData.author.name;
          email = packageData.author.email;
        }
      }
    } catch (e) {
      // Ignore JSON parsing errors
    }
  }

  // Look for git config files
  const gitConfig = files.find(file => file.path.includes('.git/config'));
  if (gitConfig && !username) {
    const nameMatch = gitConfig.content.match(/name\s*=\s*(.*)/);
    if (nameMatch) {
      username = nameMatch[1].trim();
    }
    
    const emailMatch = gitConfig.content.match(/email\s*=\s*(.*)/);
    if (emailMatch) {
      email = emailMatch[1].trim();
    }
  }

  // Look for README files for author information
  const readme = files.find(file => 
    file.path.toLowerCase().includes('readme.md') || 
    file.path.toLowerCase().includes('readme.txt')
  );
  
  if (readme && !username) {
    const authorMatch = readme.content.match(/(?:author|created by|developed by|by)(?:\s*:|\s+)([^<\n]+)/i);
    if (authorMatch) {
      username = authorMatch[1].trim();
    }
    
    const emailMatch = readme.content.match(/[\w.-]+@[\w.-]+\.\w+/);
    if (emailMatch) {
      email = emailMatch[0];
    }
  }

  return { username, email };
}

/**
 * Format a date for display
 */
export function formatDate(date: Date | string | undefined): string {
  if (!date) return '';
  
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  // If it's today, show "Today at HH:MM"
  const today = new Date();
  if (dateObj.toDateString() === today.toDateString()) {
    return `Today at ${dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  }
  
  // If it's yesterday, show "Yesterday at HH:MM"
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  if (dateObj.toDateString() === yesterday.toDateString()) {
    return `Yesterday at ${dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  }
  
  // If it's in the last 7 days, show day name
  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
  if (dateObj > oneWeekAgo) {
    return dateObj.toLocaleDateString([], { weekday: 'long' });
  }
  
  // Otherwise, show date like "Apr 14, 2023"
  return dateObj.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
}

/**
 * Get file extension from a path
 */
export function getFileExtension(filePath: string): string {
  const parts = filePath.split('.');
  if (parts.length === 1) return '';
  return parts[parts.length - 1].toLowerCase();
}

/**
 * Check if a file is likely a code file based on extension
 */
export function isCodeFile(filePath: string): boolean {
  const codeExtensions = [
    'js', 'jsx', 'ts', 'tsx',   // JavaScript/TypeScript
    'py', 'ipynb',              // Python
    'java', 'kt',               // Java/Kotlin
    'c', 'cpp', 'h', 'hpp',     // C/C++
    'cs',                       // C#
    'php',                      // PHP
    'rb',                       // Ruby
    'go',                       // Go
    'rs',                       // Rust
    'swift',                    // Swift
    'html', 'htm', 'css', 'scss', 'sass', // Web
    'sql',                      // SQL
    'sh', 'bash',               // Shell scripts
    'yml', 'yaml', 'json', 'xml', 'toml', // Config files
    'md', 'markdown',           // Markdown
    'r', 'rmd',                 // R
    'dart',                     // Dart
    'lua',                      // Lua
    'pl', 'pm',                 // Perl
    'ex', 'exs',                // Elixir
    'hs',                       // Haskell
    'clj',                      // Clojure
    'scala',                    // Scala
  ];
  
  const ext = getFileExtension(filePath);
  return codeExtensions.includes(ext);
}

/**
 * Get a summary of file types in a project
 */
export function getProjectFileSummary(files: { path: string }[]): Record<string, number> {
  const summary: Record<string, number> = {};
  
  files.forEach(file => {
    const ext = getFileExtension(file.path);
    if (ext) {
      summary[ext] = (summary[ext] || 0) + 1;
    } else {
      summary['other'] = (summary['other'] || 0) + 1;
    }
  });
  
  return summary;
}

/**
 * Get primary programming language based on file extensions
 */
export function getPrimaryLanguage(files: { path: string }[]): string | null {
  const summary = getProjectFileSummary(files);
  
  // Language mapping from extensions
  const languageMap: Record<string, string> = {
    'js': 'JavaScript',
    'jsx': 'JavaScript',
    'ts': 'TypeScript',
    'tsx': 'TypeScript',
    'py': 'Python',
    'ipynb': 'Python',
    'java': 'Java',
    'kt': 'Kotlin',
    'c': 'C',
    'cpp': 'C++',
    'h': 'C/C++',
    'hpp': 'C++',
    'cs': 'C#',
    'php': 'PHP',
    'rb': 'Ruby',
    'go': 'Go',
    'rs': 'Rust',
    'swift': 'Swift',
    'html': 'HTML',
    'css': 'CSS',
    'scss': 'SCSS',
    'sass': 'Sass',
    'r': 'R',
    'dart': 'Dart',
    'lua': 'Lua',
    'pl': 'Perl',
    'ex': 'Elixir',
    'hs': 'Haskell',
    'clj': 'Clojure',
    'scala': 'Scala',
  };
  
  // Count languages
  const languageCounts: Record<string, number> = {};
  
  for (const [ext, count] of Object.entries(summary)) {
    const language = languageMap[ext];
    if (language) {
      languageCounts[language] = (languageCounts[language] || 0) + count;
    }
  }
  
  // Find the language with the highest count
  let maxCount = 0;
  let primaryLanguage: string | null = null;
  
  for (const [language, count] of Object.entries(languageCounts)) {
    if (count > maxCount) {
      maxCount = count;
      primaryLanguage = language;
    }
  }
  
  return primaryLanguage;
}
