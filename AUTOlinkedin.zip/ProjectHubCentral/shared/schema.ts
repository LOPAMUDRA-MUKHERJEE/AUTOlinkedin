import { pgTable, text, serial, integer, boolean, timestamp, varchar, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  marketingConsent: boolean("marketing_consent").default(false),
  lastLoginAt: timestamp("last_login_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  platform: text("platform"),
});

// Projects table
export const projects = pgTable("projects", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  techStack: jsonb("tech_stack").$type<string[]>(),
  keyFeatures: jsonb("key_features").$type<string[]>(),
  userId: integer("user_id").notNull().references(() => users.id),
  fileCount: integer("file_count").notNull(),
  username: text("username"),
  email: text("email"),
  repoUrl: text("repo_url"),  // Repository URL if imported from GitHub
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Posts table
export const posts = pgTable("posts", {
  id: varchar("id").primaryKey(),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  content: text("content").notNull(),
  author: text("author"),
  headline: text("headline"),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull(),
});

// Post versions table
export const postVersions = pgTable("post_versions", {
  id: varchar("id").primaryKey(),
  postId: varchar("post_id").notNull().references(() => posts.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Define insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  marketingConsent: true,
  lastLoginAt: true,
  createdAt: true,
  platform: true,
});

export const insertProjectSchema = createInsertSchema(projects).pick({
  name: true,
  description: true,
  techStack: true,
  keyFeatures: true,
  userId: true,
  fileCount: true,
  username: true,
  email: true,
  repoUrl: true,
});

export const insertPostSchema = createInsertSchema(posts).pick({
  projectId: true,
  content: true,
  author: true,
  headline: true,
  imageUrl: true,
});

export const insertPostVersionSchema = createInsertSchema(postVersions).pick({
  postId: true,
  content: true,
});

// Define types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

export type InsertPost = z.infer<typeof insertPostSchema>;
export type Post = typeof posts.$inferSelect;

export type InsertPostVersion = z.infer<typeof insertPostVersionSchema>;
export type PostVersion = typeof postVersions.$inferSelect;
