import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

/**
 * Analyzes a project's files and extracts key information
 */
export async function analyzeProject(
  files: Array<{ path: string; content: string }>,
): Promise<{
  name: string;
  description: string;
  techStack: string[];
  keyFeatures: string[];
}> {
  // Create a summary of the project structure and content
  const fileContents = files.map(file => `File: ${file.path}\n\nContent: ${file.content.slice(0, 500)}${file.content.length > 500 ? '...(truncated)' : ''}`).join('\n\n');
  
  const filePaths = files.map(file => file.path).join('\n');

  const prompt = `
    You are an expert software project analyzer. Carefully analyze the following project files and extract:
    1. The project name (a concise, descriptive, user-friendly name that represents the purpose/nature of the project)
    2. A brief description (2-3 sentences max that clearly explain what the project does, its purpose, and primary audience)
    3. The tech stack (all programming languages, frameworks, libraries, databases, and tools used)
    4. 4-6 key features or functionality (be specific about what the project can do)

    Focus on:
    - Understanding the overall architecture and purpose of the project
    - Identifying main dependencies and technologies
    - Finding unique selling points or important features
    - Extracting the core functionality from the main files
    - Looking for configuration files to understand the technology stack

    If you see package.json, setup.py, Cargo.toml, or similar dependency files, pay special attention to them.
    If you see README.md, project descriptions, or documentation, prioritize those for extracting the project name and description.

    Respond with this exact JSON format:
    {
      "name": "Project Name",
      "description": "Brief project description that explains the purpose and value of the project",
      "techStack": ["Tech1", "Tech2", "Tech3", "Tech4", "Tech5"],
      "keyFeatures": ["Detailed Feature 1", "Detailed Feature 2", "Detailed Feature 3", "Detailed Feature 4"]
    }

    File paths:
    ${filePaths}

    First few files with content (most important ones):
    ${fileContents.slice(0, 10000)}
  `;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.5,
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content || '{}';
    const result = JSON.parse(content);
    
    return {
      name: result.name,
      description: result.description,
      techStack: result.techStack,
      keyFeatures: result.keyFeatures,
    };
  } catch (error) {
    console.error("Error analyzing project:", error);
    
    // Enhanced, more sophisticated fallback analysis without using external APIs
    
    // Language and framework detection based on file extensions and content
    const fileExtensions = files.reduce((acc, file) => {
      const ext = file.path.split('.').pop()?.toLowerCase() || '';
      if (ext && !['md', 'txt', 'gitignore', 'yml', 'yaml'].includes(ext)) {
        acc[ext] = (acc[ext] || 0) + 1;
      }
      return acc;
    }, {} as Record<string, number>);
    
    // Get most common file extensions as tech stack
    const techStack: string[] = [];
    const frameworks: string[] = [];
    const libraries: string[] = [];
    
    // Framework & library detection through dependencies
    let packageJsonFile = files.find(file => file.path.includes('package.json'));
    let requirementsFile = files.find(file => file.path.includes('requirements.txt'));
    let podfileFile = files.find(file => file.path.includes('Podfile'));
    let gradleFile = files.find(file => file.path.includes('build.gradle'));
    let gemfileFile = files.find(file => file.path.includes('Gemfile'));
    let cargoFile = files.find(file => file.path.includes('Cargo.toml'));
    
    // Extract package info from package.json
    if (packageJsonFile) {
      try {
        const packageJson = JSON.parse(packageJsonFile.content);
        
        // Detect frontend framework
        if (packageJson.dependencies) {
          if (packageJson.dependencies.react) frameworks.push('React');
          if (packageJson.dependencies.vue) frameworks.push('Vue.js');
          if (packageJson.dependencies.angular) frameworks.push('Angular');
          if (packageJson.dependencies.svelte) frameworks.push('Svelte');
          if (packageJson.dependencies.next) frameworks.push('Next.js');
          if (packageJson.dependencies.nuxt) frameworks.push('Nuxt.js');
          
          // Backend frameworks
          if (packageJson.dependencies.express) frameworks.push('Express.js');
          if (packageJson.dependencies.koa) frameworks.push('Koa.js');
          if (packageJson.dependencies.fastify) frameworks.push('Fastify');
          if (packageJson.dependencies.nest) frameworks.push('NestJS');
          
          // Add more important dependencies
          if (packageJson.dependencies.typescript) libraries.push('TypeScript');
          if (packageJson.dependencies.tailwindcss) libraries.push('Tailwind CSS');
          if (packageJson.dependencies.bootstrap) libraries.push('Bootstrap');
          if (packageJson.dependencies.mui || packageJson.dependencies['@material-ui/core']) libraries.push('Material UI');
          if (packageJson.dependencies.redux) libraries.push('Redux');
          
          // Database connections
          if (packageJson.dependencies.mongoose || packageJson.dependencies.mongodb) libraries.push('MongoDB');
          if (packageJson.dependencies.sequelize || packageJson.dependencies.mysql || packageJson.dependencies.pg) libraries.push('SQL Database');
          if (packageJson.dependencies.firebase) libraries.push('Firebase');
        }
      } catch (e) {
        console.log('Error parsing package.json:', e);
      }
    }
    
    // Python project detection
    if (requirementsFile) {
      const content = requirementsFile.content.toLowerCase();
      if (content.includes('django')) frameworks.push('Django');
      if (content.includes('flask')) frameworks.push('Flask');
      if (content.includes('fastapi')) frameworks.push('FastAPI');
      if (content.includes('pandas') || content.includes('numpy')) libraries.push('Data Science');
      if (content.includes('tensorflow') || content.includes('keras') || content.includes('pytorch')) libraries.push('Machine Learning');
    }
    
    // Get programming languages from file extensions
    const langMap: Record<string, string> = {
      'js': 'JavaScript',
      'ts': 'TypeScript',
      'py': 'Python',
      'java': 'Java',
      'c': 'C',
      'cpp': 'C++',
      'cs': 'C#',
      'go': 'Go',
      'rb': 'Ruby',
      'php': 'PHP',
      'html': 'HTML',
      'css': 'CSS',
      'jsx': 'React JSX',
      'tsx': 'TypeScript JSX',
      'vue': 'Vue.js',
      'rs': 'Rust',
      'swift': 'Swift',
      'kt': 'Kotlin',
      'sql': 'SQL',
      'sh': 'Shell',
      'r': 'R',
      'dart': 'Dart',
      'scala': 'Scala',
      'elm': 'Elm',
      'ex': 'Elixir',
      'clj': 'Clojure',
      'hs': 'Haskell',
    };
    
    Object.entries(fileExtensions)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .forEach(([ext, count]) => {
        const lang = langMap[ext] || ext.toUpperCase();
        if (!techStack.includes(lang)) {
          techStack.push(lang);
        }
      });
    
    // Add frameworks and libraries to tech stack
    frameworks.forEach(framework => {
      if (!techStack.includes(framework)) {
        techStack.push(framework);
      }
    });
    
    // Limit to 5 most relevant technologies
    const finalTechStack = techStack.concat(libraries).slice(0, 5);
    
    // Project name detection
    let projectName = "Code Project";
    
    // Look for better name in package.json
    if (packageJsonFile) {
      try {
        const packageJson = JSON.parse(packageJsonFile.content);
        if (packageJson.name && packageJson.name !== "project" && packageJson.name !== "app") {
          // Format the package name to be more readable
          projectName = packageJson.name
            .replace(/-/g, ' ')
            .replace(/_/g, ' ')
            .split(' ')
            .map((word: string) => word.charAt(0).toUpperCase() + word.slice(1))
            .join(' ');
        }
      } catch (e) {
        console.log('Error parsing package.json for name:', e);
      }
    }
    
    // Look for README for better info
    const readmeFile = files.find(file => 
      file.path.toLowerCase().includes('readme.md') || 
      file.path.toLowerCase().includes('readme.txt')
    );
    
    let description = "";
    let keyFeatures: string[] = [];
    
    if (readmeFile) {
      const content = readmeFile.content;
      
      // Extract potential project name from first heading
      const titleMatch = content.match(/^#\s+([^\n]+)/m);
      if (titleMatch && titleMatch[1]) {
        projectName = titleMatch[1].trim();
      }
      
      // Extract description from the first paragraph after the title
      // Find the section after the title heading
      const sections = content.split(/^#.*?\n+/m);
      const firstSection = sections.length > 1 ? sections[1] : "";
      // Extract the first paragraph
      const paragraphs = firstSection.split(/\n\n|\n#|\n\*\*/);
      const firstParagraph = paragraphs.length > 0 ? paragraphs[0].trim() : "";
      // Process the extracted paragraph
      description = firstParagraph
        .replace(/\n/g, ' ')
        .replace(/\s\s+/g, ' ')
        .trim();
      
      // Limit description length
      if (description.length > 200) {
        description = description.substring(0, 197) + '...';
      }
      
      // Extract features from bullet points or section
      const featuresMatch = content.match(/(?:features|functionality).*?\n((?:\s*[\*\-\+]\s+[^\n]+\n)+)/i);
      if (featuresMatch && featuresMatch[1]) {
        keyFeatures = featuresMatch[1]
          .split('\n')
          .filter(line => line.match(/^\s*[\*\-\+]/))
          .map(line => line.replace(/^\s*[\*\-\+]\s+/, '').trim())
          .filter(feature => feature.length > 0)
          .slice(0, 5);
      }
    }
    
    // If key features weren't found, create generic ones based on tech stack
    if (keyFeatures.length === 0) {
      const hasWeb = finalTechStack.some(tech => 
        ['HTML', 'CSS', 'React', 'Vue.js', 'Angular', 'Next.js', 'Svelte'].includes(tech)
      );
      
      const hasBackend = finalTechStack.some(tech => 
        ['Express.js', 'Flask', 'Django', 'FastAPI', 'NestJS', 'Koa.js'].includes(tech)
      );
      
      const hasDatabase = finalTechStack.some(tech => 
        ['MongoDB', 'SQL Database', 'Firebase'].includes(tech)
      );
      
      if (hasWeb) keyFeatures.push('User-friendly web interface');
      if (hasBackend) keyFeatures.push('Robust backend API');
      if (hasDatabase) keyFeatures.push('Data persistence with database integration');
      
      // Add generic features if still needed
      if (keyFeatures.length < 3) {
        keyFeatures.push('Application functionality');
        keyFeatures.push('Code organization');
        keyFeatures.push('Error handling');
      }
    }
    
    // If no description was found, create one based on tech stack
    if (!description) {
      const mainLang = finalTechStack[0] || 'code';
      const mainFramework = frameworks[0] || '';
      
      const projectType = hasWebApp(files) ? 'web application' : 
                          hasMobileApp(files) ? 'mobile application' : 
                          'software project';
                          
      description = `A ${mainLang}${mainFramework ? ' ' + mainFramework : ''} ${projectType} with multiple components and features.`;
    }
    
    return {
      name: projectName,
      description: description,
      techStack: finalTechStack.length > 0 ? finalTechStack : ["JavaScript"],
      keyFeatures: keyFeatures.length > 0 ? keyFeatures : ["Import successful", "Basic project structure detected"],
    };
  }
}

// Helper function to detect web apps
function hasWebApp(files: Array<{ path: string; content: string }>) {
  return files.some(file => 
    file.path.includes('index.html') ||
    file.path.includes('public/index.html') ||
    file.path.includes('src/App') ||
    file.path.includes('components') ||
    file.path.includes('pages')
  );
}

// Helper function to detect mobile apps
function hasMobileApp(files: Array<{ path: string; content: string }>) {
  return files.some(file => 
    file.path.includes('AndroidManifest.xml') ||
    file.path.includes('Info.plist') ||
    file.path.includes('MainActivity.') ||
    file.path.includes('AppDelegate.')
  );
}

/**
 * Generates a LinkedIn post based on project details
 */
export async function generateLinkedInPost(
  projectDetails: {
    name: string;
    description: string;
    techStack: string[];
    keyFeatures: string[];
  },
  preferences: {
    tone: string;
    length: string;
    audience: string;
  },
  username: string
): Promise<string> {
  const prompt = `
    Generate a professional LinkedIn post about the following project:
    
    Project Name: ${projectDetails.name}
    Description: ${projectDetails.description}
    Tech Stack: ${projectDetails.techStack.join(', ')}
    Key Features: ${projectDetails.keyFeatures.join(', ')}
    
    Preferences:
    - Tone: ${preferences.tone}
    - Length: ${preferences.length === 'standard' ? 'Standard (around 150-200 words)' : 'In-depth (around 250-350 words)'}
    - Target Audience: ${preferences.audience}
    
    The post should:
    1. Start with an attention-grabbing introduction
    2. Highlight the project's purpose and value
    3. Mention key technologies used
    4. Include the main features
    5. End with a call to action or invitation for feedback
    6. Include relevant hashtags
    7. Use appropriate emojis for readability
    
    The post should be in the first person, as if ${username} is sharing their own project.
  `;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7,
    });

    return response.choices[0].message.content || "";
  } catch (error) {
    console.error("Error generating LinkedIn post:", error);
    
    // Create a more sophisticated fallback with tone variations for LinkedIn post
    const { tone, length, audience } = preferences;
    
    // Format tech stack for display
    const techStackText = projectDetails.techStack.length > 0 
      ? projectDetails.techStack.join(', ')
      : "various technologies";
    
    // Format features for display
    const featuresList = projectDetails.keyFeatures.length > 0
      ? projectDetails.keyFeatures
      : ["Efficient application structure", "Clean code implementation", "Thoughtful user experience"];
    
    // Emotion indicators based on tone
    let emoji = "🚀"; // Default
    let toneIndicator = "";
    let adjective = "exciting";
    let verb = "built";
    let callToAction = "I'd love to hear your thoughts and feedback!";
    
    // Adjust based on selected tone
    switch(tone.toLowerCase()) {
      case "professional":
        emoji = "📊";
        toneIndicator = "I'm pleased to";
        adjective = "professional";
        verb = "developed";
        callToAction = "I welcome any professional feedback or potential collaboration opportunities.";
        break;
      case "enthusiastic":
        emoji = "🚀";
        toneIndicator = "I'm super excited to";
        adjective = "amazing";
        verb = "created";
        callToAction = "I'm eager to hear what you think! Drop a comment or message me with your feedback!";
        break;
      case "technical":
        emoji = "⚙️";
        toneIndicator = "I'd like to";
        adjective = "technical";
        verb = "engineered";
        callToAction = "Technical feedback and implementation questions are welcome.";
        break;
      case "casual":
        emoji = "👋";
        toneIndicator = "Just wanted to";
        adjective = "cool";
        verb = "made";
        callToAction = "Let me know what you think! Open to all feedback.";
        break;
      default:
        emoji = "🚀";
        toneIndicator = "I'm excited to";
        adjective = "innovative";
        verb = "built";
    }
    
    // Adjust for audience
    let audienceSpecificText = "";
    switch(audience.toLowerCase()) {
      case "recruiters":
        audienceSpecificText = "This project demonstrates my skills in " + 
          (projectDetails.techStack.length > 1 ? 
            `${projectDetails.techStack.slice(0, -1).join(', ')} and ${projectDetails.techStack[projectDetails.techStack.length-1]}` : 
            techStackText) + 
          ". I'm interested in opportunities where I can continue to apply these technologies.";
        break;
      case "developers":
        audienceSpecificText = "I solved several interesting technical challenges in this project, especially around " + 
          (featuresList[0] || "implementation") + ". The codebase emphasizes maintainability and best practices.";
        break;
      case "general":
        audienceSpecificText = "This project showcases what's possible with modern technology and thoughtful design.";
        break;
      case "technical":
        audienceSpecificText = "The architecture implements " + 
          (featuresList[0] || "core functionality") + 
          " using " + techStackText + " to ensure scalability and performance.";
        break;
    }
    
    // Select relevant hashtags
    const hashtagBase = ["TechProject", "Coding", "Development"];
    const techHashtags = projectDetails.techStack.slice(0, 2).map(tech => 
      "#" + tech.replace(/[^a-zA-Z0-9]/g, '')
    );
    
    // Adjust content length based on preference
    let featureIntro = "";
    let featuresFormatted = "";
    
    if (length === "standard") {
      // Shorter post - use a single paragraph for features
      featuresFormatted = "Key features include " + featuresList.slice(0, 3).join(", ") + ".";
    } else {
      // Longer post - use bullet points
      featureIntro = "The project includes these key features:";
      featuresFormatted = featuresList.map(feature => `• ${feature}`).join("\n");
    }
    
    // Build the final post with variations based on preferences
    return `${emoji} ${toneIndicator} share my ${adjective} project: ${projectDetails.name}!

${projectDetails.description}

I ${verb} this using ${techStackText}. ${length === "standard" ? featuresFormatted : ""}

${length === "in-depth" ? featureIntro : ""}
${length === "in-depth" ? featuresFormatted : ""}

${audienceSpecificText}

${callToAction}

#${hashtagBase[Math.floor(Math.random() * hashtagBase.length)]} ${techHashtags.join(' ')} #Portfolio ${audience === "recruiters" ? "#OpenToWork" : "#OpenSource"}`;
  }
}

/**
 * AI chat assistant for post refinement
 */
export async function getChatResponse(
  prompt: string,
  postContent: string,
  projectDetails: {
    name: string;
    techStack: string[];
  }
): Promise<{ message: string; updatedPost?: string }> {
  const systemPrompt = `
    You are an AI assistant helping users refine their LinkedIn posts about their coding projects. 
    The user will ask you to modify their post in various ways. You should:
    
    1. Answer their questions or fulfil their requests related to the post
    2. If they request changes to the post (like adding emojis, making it more technical, etc.), provide both:
       - A helpful response explaining what you changed
       - An updated version of the entire post with the requested changes
    
    Current project: ${projectDetails.name}
    Technologies: ${projectDetails.techStack.join(', ')}
    
    Current LinkedIn post:
    "${postContent}"
  `;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: prompt }
      ],
      temperature: 0.7,
    });

    const messageContent = response.choices[0].message.content || "";
    
    // Check if the response contains an updated post
    const containsUpdatedPost = 
      messageContent.includes("Updated post:") || 
      messageContent.includes("Here's the updated post:") ||
      messageContent.includes("Here is the updated post:");
    
    if (containsUpdatedPost) {
      // Extract the updated post from the response
      let updatedPost = "";
      const postMarkers = [
        "Updated post:",
        "Here's the updated post:",
        "Here is the updated post:",
        "Here's your updated post:"
      ];
      
      for (const marker of postMarkers) {
        if (messageContent.includes(marker)) {
          updatedPost = messageContent.split(marker)[1].trim();
          break;
        }
      }
      
      // If still didn't find it, try to extract anything that might be the post
      if (!updatedPost) {
        const lines = messageContent.split('\n');
        if (lines.length > 3) {
          // Assume the post is in the second half of the message
          updatedPost = lines.slice(Math.floor(lines.length / 2)).join('\n');
        }
      }
      
      return { 
        message: messageContent.replace(updatedPost, "").trim(), 
        updatedPost 
      };
    }
    
    return { message: messageContent };
  } catch (error) {
    console.error("Error in chat response:", error);
    
    // Provide a fallback response if OpenAI fails
    return { 
      message: "I couldn't process your request due to API limitations. Here are some general suggestions for improving your post:\n\n1. Add relevant emojis to make your post more engaging\n2. Include specific technical details about your implementation\n3. Add a clear call-to-action at the end\n4. Use more professional language if targeting recruiters\n5. Consider adding hashtags relevant to your technologies" 
    };
  }
}
