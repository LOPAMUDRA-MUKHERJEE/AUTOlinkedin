import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { setupProjectRoutes } from "./projects";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);
  
  // Setup project-related routes
  setupProjectRoutes(app);
  
  // Admin routes
  app.get("/api/admin/users", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    // Check if user is admin (in a real app, you would have an isAdmin property)
    if ((req.user as any).id !== 1) {
      return res.status(403).send("Forbidden");
    }
    
    const users = await storage.getAllUsers();
    res.json(users);
  });
  
  app.post("/api/admin/send-email", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    // Check if user is admin
    if ((req.user as any).id !== 1) {
      return res.status(403).send("Forbidden");
    }
    
    const { subject, content } = req.body;
    
    if (!subject || !content) {
      return res.status(400).send("Missing subject or content");
    }
    
    // Get users who opted in for marketing emails
    const subscribedUsers = await storage.getMarketingSubscribers();
    
    // In a real app, you would send emails here
    // For the MVP, we'll just return the list of users who would receive the email
    res.json({
      message: "Email would be sent to the following users",
      recipients: subscribedUsers.map(user => user.email),
      count: subscribedUsers.length
    });
  });

  const httpServer = createServer(app);

  return httpServer;
}
