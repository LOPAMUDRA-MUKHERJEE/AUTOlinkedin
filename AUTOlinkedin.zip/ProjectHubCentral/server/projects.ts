import type { Express, Request, Response } from "express";
import multer from "multer";
import { storage } from "./storage";
import { analyzeProject, generateLinkedInPost, getChatResponse } from "./openai";
import { randomUUID } from "crypto";
import fs from "fs";
import path from "path";
import { exec } from "child_process";
import { promisify } from "util";
import { extractUsernameAndEmail } from "../shared/utils";

// Add typings for Request with files
declare global {
  namespace Express {
    interface Request {
      files?: { [fieldname: string]: Express.Multer.File[] } | Express.Multer.File[];
    }
  }
}

const execAsync = promisify(exec);

// Setup multer for file uploads
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const userId = (req.user as any)?.id;
      if (!userId) {
        return cb(new Error("User not authenticated"), "");
      }
      
      const uploadDir = path.join(
        process.env.TEMP_UPLOAD_DIR || "uploads",
        userId.toString(),
        randomUUID()
      );
      
      // Create directory if it doesn't exist
      fs.mkdirSync(uploadDir, { recursive: true });
      
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      // Keep the original file name and path structure
      const sanitizedPath = file.originalname.replace(/\.\./g, "");
      cb(null, sanitizedPath);
    },
  }),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB per file
  },
});

export function setupProjectRoutes(app: Express) {
  // Middleware to check authentication
  const isAuthenticated = (req: Request, res: Response, next: Function) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).send("Unauthorized");
  };

  // Project upload endpoint
  app.post(
    "/api/projects/upload",
    isAuthenticated,
    upload.array("files"),
    async (req, res) => {
      try {
        if (!req.files || !Array.isArray(req.files) || req.files.length === 0) {
          return res.status(400).send("No files uploaded");
        }
        
        const user = req.user as any;
        const uploadedFiles = req.files as Express.Multer.File[];
        
        // Read file contents for analysis
        const files = await Promise.all(
          uploadedFiles.map(async (file) => {
            try {
              const content = await fs.promises.readFile(file.path, "utf-8");
              return {
                path: file.originalname,
                content: content,
              };
            } catch (err) {
              // If we can't read as text, just note the binary file
              return {
                path: file.originalname,
                content: "[Binary file]",
              };
            }
          })
        );
        
        // Extract potential username and email from files
        const { username, email } = extractUsernameAndEmail(files);
        
        let projectAnalysis;
        
        try {
          // Try to analyze the project files with OpenAI
          projectAnalysis = await analyzeProject(files);
        } catch (error) {
          console.error("OpenAI analysis failed for direct upload, using basic analysis:", error);
          
          // Fallback: Basic file analysis without OpenAI
          const fileExtensions = files.reduce((acc, file) => {
            const ext = file.path.split('.').pop()?.toLowerCase() || '';
            if (ext && !['md', 'txt', 'json', 'gitignore', 'yml', 'yaml'].includes(ext)) {
              acc[ext] = (acc[ext] || 0) + 1;
            }
            return acc;
          }, {} as Record<string, number>);
          
          // Get most common file extensions as tech stack
          const techStack = Object.entries(fileExtensions)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([ext]) => {
              const langMap: Record<string, string> = {
                'js': 'JavaScript',
                'ts': 'TypeScript',
                'py': 'Python',
                'java': 'Java',
                'c': 'C',
                'cpp': 'C++',
                'cs': 'C#',
                'go': 'Go',
                'rb': 'Ruby',
                'php': 'PHP',
                'html': 'HTML',
                'css': 'CSS',
                'jsx': 'React',
                'tsx': 'React with TypeScript',
                'vue': 'Vue.js',
                'rs': 'Rust',
                'swift': 'Swift',
                'kt': 'Kotlin',
              };
              return langMap[ext] || ext.toUpperCase();
            });
          
          // Get a name based on the first few files
          let projectName = "Uploaded Project";
          if (files.length > 0) {
            projectName = files[0].path.split('/').pop()?.split('.')[0] || "Uploaded Project";
            projectName = projectName.charAt(0).toUpperCase() + projectName.slice(1);
          }
          
          projectAnalysis = {
            name: projectName,
            description: "A project uploaded directly to AUTOlinkedin.",
            techStack: techStack.length > 0 ? techStack : ["Unknown"],
            keyFeatures: ["Direct upload successful", "Basic project structure detected"],
          };
        }
        
        // Create project in storage
        const project = await storage.createProject({
          name: projectAnalysis.name,
          description: projectAnalysis.description,
          techStack: projectAnalysis.techStack,
          keyFeatures: projectAnalysis.keyFeatures,
          userId: user.id,
          fileCount: uploadedFiles.length,
          username: username || user.username,
          email: email || user.email,
        });
        
        // Clean up uploaded files
        // In a production system, you might want to store these files persistently
        // For this MVP, we'll analyze and then remove them
        for (const file of uploadedFiles) {
          fs.unlinkSync(file.path);
        }
        
        res.status(200).json({
          message: "Project uploaded and analyzed successfully",
          projectId: project.id,
        });
      } catch (error) {
        console.error("Error uploading project:", error);
        res.status(500).send("Error uploading project");
      }
    }
  );

  // Get project details
  app.get("/api/projects/details", isAuthenticated, async (req, res) => {
    try {
      const projectId = req.query.projectId as string;
      
      if (!projectId) {
        return res.status(400).send("Project ID is required");
      }
      
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).send("Project not found");
      }
      
      // Check if user owns this project
      if (project.userId !== (req.user as any).id) {
        return res.status(403).send("Unauthorized access to project");
      }
      
      res.json(project);
    } catch (error) {
      console.error("Error fetching project details:", error);
      res.status(500).send("Error fetching project details");
    }
  });

  // Generate LinkedIn post
  app.post("/api/projects/generate-post", isAuthenticated, async (req, res) => {
    try {
      const { projectId, tone, length, audience } = req.body;
      
      if (!projectId || !tone || !length || !audience) {
        return res.status(400).send("Missing required fields");
      }
      
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).send("Project not found");
      }
      
      // Check if user owns this project
      if (project.userId !== (req.user as any).id) {
        return res.status(403).send("Unauthorized access to project");
      }
      
      // Generate the post
      const postContent = await generateLinkedInPost(
        {
          name: project.name || "",
          description: project.description || "",
          techStack: project.techStack || [],
          keyFeatures: project.keyFeatures || [],
        },
        { tone, length, audience },
        project.username || (req.user as any).username
      );
      
      // Check if there's an existing post for this project
      let post = await storage.getPostByProjectId(projectId);
      
      if (!post) {
        // Create a new post
        post = await storage.createPost(
          projectId,
          postContent,
          project.username || (req.user as any).username,
          project.techStack ? 
            `${project.username || "User"} • ${(project.techStack || []).slice(0, 3).join(' • ')}` : 
            `${project.username || "User"}`
        );
      } else {
        // Update existing post
        await storage.savePostVersion(post.id, postContent);
      }
      
      res.json({ message: "Post generated successfully" });
    } catch (error) {
      console.error("Error generating post:", error);
      res.status(500).send("Error generating LinkedIn post");
    }
  });

  // Get current post for a project
  app.get("/api/projects/current-post", isAuthenticated, async (req, res) => {
    try {
      const projectId = req.query.projectId as string;
      
      if (!projectId) {
        return res.status(400).send("Project ID is required");
      }
      
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).send("Project not found");
      }
      
      // Check if user owns this project
      if (project.userId !== (req.user as any).id) {
        return res.status(403).send("Unauthorized access to project");
      }
      
      const post = await storage.getPostByProjectId(projectId);
      
      if (!post) {
        return res.status(404).send("No posts found for this project");
      }
      
      res.json(post);
    } catch (error) {
      console.error("Error fetching post:", error);
      res.status(500).send("Error fetching post");
    }
  });

  // Save a new version of a post
  app.post("/api/projects/save-post-version", isAuthenticated, async (req, res) => {
    try {
      const { projectId, postContent } = req.body;
      
      if (!projectId || !postContent) {
        return res.status(400).send("Missing required fields");
      }
      
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).send("Project not found");
      }
      
      // Check if user owns this project
      if (project.userId !== (req.user as any).id) {
        return res.status(403).send("Unauthorized access to project");
      }
      
      // Get the post
      const post = await storage.getPostByProjectId(projectId);
      
      if (!post) {
        return res.status(404).send("No post found for this project");
      }
      
      // Save the new version
      const version = await storage.savePostVersion(post.id, postContent);
      
      res.json({
        message: "Post version saved successfully",
        versionId: version.id,
      });
    } catch (error) {
      console.error("Error saving post version:", error);
      res.status(500).send("Error saving post version");
    }
  });

  // Get post versions
  app.get("/api/projects/post-versions", isAuthenticated, async (req, res) => {
    try {
      const projectId = req.query.projectId as string;
      
      if (!projectId) {
        return res.status(400).send("Project ID is required");
      }
      
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).send("Project not found");
      }
      
      // Check if user owns this project
      if (project.userId !== (req.user as any).id) {
        return res.status(403).send("Unauthorized access to project");
      }
      
      const post = await storage.getPostByProjectId(projectId);
      
      if (!post) {
        return res.status(404).send("No post found for this project");
      }
      
      const versions = await storage.getPostVersions(post.id);
      
      res.json(versions);
    } catch (error) {
      console.error("Error fetching post versions:", error);
      res.status(500).send("Error fetching post versions");
    }
  });

  // AI chat endpoint
  app.post("/api/projects/chat", isAuthenticated, async (req, res) => {
    try {
      const { projectId, prompt, postContent } = req.body;
      
      if (!projectId || !prompt || !postContent) {
        return res.status(400).send("Missing required fields");
      }
      
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).send("Project not found");
      }
      
      // Check if user owns this project
      if (project.userId !== (req.user as any).id) {
        return res.status(403).send("Unauthorized access to project");
      }
      
      // Get chat response
      const response = await getChatResponse(
        prompt,
        postContent,
        {
          name: project.name || "",
          techStack: project.techStack || [],
        }
      );
      
      // If the chat response includes an updated post, save it
      if (response.updatedPost) {
        const post = await storage.getPostByProjectId(projectId);
        if (post) {
          await storage.savePostVersion(post.id, response.updatedPost);
        }
      }
      
      res.json(response);
    } catch (error) {
      console.error("Error processing chat:", error);
      res.status(500).send("Error processing chat request");
    }
  });

  // GitHub repository clone endpoint
  app.post("/api/projects/clone", isAuthenticated, async (req, res) => {
    try {
      const { url, name } = req.body;
      const user = req.user as any;

      if (!url) {
        return res.status(400).send("GitHub repository URL is required");
      }

      if (!name) {
        return res.status(400).send("Project name is required");
      }

      // Simple validation of GitHub URL format
      if (!url.includes("github.com/")) {
        return res.status(400).send("Invalid GitHub repository URL");
      }

      // Extract repository information
      const repoRegex = /github\.com\/([^\/]+)\/([^\/]+)/;
      const matches = url.match(repoRegex);
      
      if (!matches || matches.length < 3) {
        return res.status(400).send("Could not parse GitHub repository URL");
      }

      const [, owner, repo] = matches;
      const repoName = repo.replace(".git", "");
      
      // Create temporary directory for cloning
      const userId = user.id;
      const projectId = randomUUID();
      const tempDir = path.join(
        process.env.TEMP_UPLOAD_DIR || "uploads",
        userId.toString(),
        projectId
      );
      
      // Create directory if it doesn't exist
      fs.mkdirSync(tempDir, { recursive: true });
      
      try {
        // Clone the repository (shallow clone to save bandwidth and time)
        await execAsync(`git clone --depth 1 ${url} ${tempDir}`);
        
        // Remove .git directory to save space
        const gitDir = path.join(tempDir, ".git");
        if (fs.existsSync(gitDir)) {
          fs.rmSync(gitDir, { recursive: true, force: true });
        }
        
        // Read files for basic analysis
        const allFiles: {path: string, content: string}[] = [];
        
        // Function to recursively read files
        const readDir = async (dir: string, baseDir: string = "") => {
          const entries = await fs.promises.readdir(dir, { withFileTypes: true });
          
          for (const entry of entries) {
            const fullPath = path.join(dir, entry.name);
            const relativePath = path.join(baseDir, entry.name);
            
            if (entry.isDirectory()) {
              // Skip node_modules and other large directories
              if (entry.name === "node_modules" || entry.name === ".git" || 
                  entry.name === "dist" || entry.name === "build") {
                continue;
              }
              
              await readDir(fullPath, relativePath);
            } else {
              try {
                // Only read text files, max 100KB to avoid large binaries
                const stat = await fs.promises.stat(fullPath);
                if (stat.size < 100 * 1024) {
                  try {
                    const content = await fs.promises.readFile(fullPath, "utf-8");
                    allFiles.push({
                      path: relativePath,
                      content,
                    });
                  } catch (err) {
                    // If we can't read as text, skip
                    allFiles.push({
                      path: relativePath,
                      content: "[Binary file]",
                    });
                  }
                } else {
                  allFiles.push({
                    path: relativePath,
                    content: "[Large file skipped]",
                  });
                }
              } catch (err) {
                console.error(`Error reading file ${fullPath}:`, err);
              }
            }
          }
        };
        
        // Read all files
        await readDir(tempDir);
        
        // Extract potential username and email from files
        const { username, email } = extractUsernameAndEmail(allFiles);
        
        let projectAnalysis;
        
        try {
          // Try to analyze the project files with OpenAI
          projectAnalysis = await analyzeProject(allFiles);
        } catch (error) {
          console.error("OpenAI analysis failed for GitHub import, using basic analysis:", error);
          
          // Fallback: Basic file analysis without OpenAI
          const fileExtensions = allFiles.reduce((acc, file) => {
            const ext = path.extname(file.path).toLowerCase().substring(1);
            if (ext && !['md', 'txt', 'json', 'gitignore', 'yml', 'yaml'].includes(ext)) {
              acc[ext] = (acc[ext] || 0) + 1;
            }
            return acc;
          }, {} as Record<string, number>);
          
          // Get most common file extensions as tech stack
          const techStack = Object.entries(fileExtensions)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([ext]) => {
              const langMap: Record<string, string> = {
                'js': 'JavaScript',
                'ts': 'TypeScript',
                'py': 'Python',
                'java': 'Java',
                'c': 'C',
                'cpp': 'C++',
                'cs': 'C#',
                'go': 'Go',
                'rb': 'Ruby',
                'php': 'PHP',
                'html': 'HTML',
                'css': 'CSS',
                'jsx': 'React',
                'tsx': 'React with TypeScript',
                'vue': 'Vue.js',
                'rs': 'Rust',
                'swift': 'Swift',
                'kt': 'Kotlin',
              };
              return langMap[ext] || ext.toUpperCase();
            });
          
          projectAnalysis = {
            name: name || repoName,
            description: `A GitHub project imported from ${owner}/${repoName}.`,
            techStack: techStack.length > 0 ? techStack : ["Unknown"],
            keyFeatures: ["GitHub import successful", "Basic project structure detected"],
          };
        }
        
        // Create project in storage
        const project = await storage.createProject({
          name: name || projectAnalysis.name,
          description: projectAnalysis.description,
          techStack: projectAnalysis.techStack,
          keyFeatures: projectAnalysis.keyFeatures,
          userId: user.id,
          fileCount: allFiles.length,
          repoUrl: url,
          username: username || user.username,
          email: email || user.email,
        });
        
        // Clean up temporary directory
        fs.rmSync(tempDir, { recursive: true, force: true });
        
        // Return success
        res.status(200).json({
          message: "GitHub repository cloned and analyzed successfully",
          projectId: project.id,
        });
      } catch (error) {
        console.error("Error cloning repository:", error);
        
        // Clean up the directory
        fs.rmSync(tempDir, { recursive: true, force: true });
        
        res.status(500).json({
          error: "Failed to clone repository. Ensure the repository is public and accessible."
        });
      }
    } catch (error) {
      console.error("Error in /api/projects/clone:", error);
      res.status(500).json({ error: "An unexpected error occurred" });
    }
  });

  // GitHub repository import (deprecated - keeping for backward compatibility)
  app.post("/api/projects/github", isAuthenticated, async (req, res) => {
    try {
      const { url } = req.body;
      const user = req.user as any;

      if (!url) {
        return res.status(400).send("GitHub repository URL is required");
      }

      // Simple validation of GitHub URL format
      if (!url.includes("github.com/")) {
        return res.status(400).send("Invalid GitHub repository URL");
      }

      // Extract repository information
      const repoRegex = /github\.com\/([^\/]+)\/([^\/]+)/;
      const matches = url.match(repoRegex);
      
      if (!matches || matches.length < 3) {
        return res.status(400).send("Could not parse GitHub repository URL");
      }

      const [, owner, repo] = matches;
      const repoName = repo.replace(".git", "");
      
      // Create temporary directory for cloning
      const userId = user.id;
      const projectId = randomUUID();
      const tempDir = path.join(
        process.env.TEMP_UPLOAD_DIR || "uploads",
        userId.toString(),
        projectId
      );
      
      // Create directory if it doesn't exist
      fs.mkdirSync(tempDir, { recursive: true });
      
      // Clone the repository (shallow clone to save bandwidth and time)
      try {
        await execAsync(`git clone --depth 1 ${url} ${tempDir}`);
      } catch (error) {
        // Clean up the directory
        fs.rmSync(tempDir, { recursive: true, force: true });
        return res.status(500).send("Failed to clone repository. Ensure the repository is public and accessible.");
      }
      
      // Remove .git directory to save space
      const gitDir = path.join(tempDir, ".git");
      if (fs.existsSync(gitDir)) {
        fs.rmSync(gitDir, { recursive: true, force: true });
      }
      
      // Get all files in the directory
      const allFiles: {path: string, content: string}[] = [];
      
      const readDir = async (dir: string, baseDir: string = "") => {
        const entries = await fs.promises.readdir(dir, { withFileTypes: true });
        
        for (const entry of entries) {
          const fullPath = path.join(dir, entry.name);
          const relativePath = path.join(baseDir, entry.name);
          
          if (entry.isDirectory()) {
            // Skip node_modules and other large directories
            if (entry.name === "node_modules" || entry.name === ".git" || entry.name === "dist" || entry.name === "build") {
              continue;
            }
            await readDir(fullPath, relativePath);
          } else {
            try {
              // Skip binary files and very large files
              const stats = await fs.promises.stat(fullPath);
              if (stats.size > 1024 * 500) { // Skip files larger than 500KB
                continue;
              }
              
              const content = await fs.promises.readFile(fullPath, "utf-8");
              allFiles.push({
                path: relativePath,
                content
              });
            } catch (err) {
              // If we can't read it as text, just skip
              continue;
            }
          }
        }
      };
      
      await readDir(tempDir);
      
      // Extract potential username and email from files
      const { username, email } = extractUsernameAndEmail(allFiles);
      
      let projectAnalysis;
      
      try {
        // Try to analyze the project files with OpenAI
        projectAnalysis = await analyzeProject(allFiles);
      } catch (error) {
        console.error("OpenAI analysis failed, using basic analysis:", error);
        
        // Fallback: Basic file analysis without OpenAI
        const fileExtensions = allFiles.reduce((acc, file) => {
          const ext = file.path.split('.').pop()?.toLowerCase() || '';
          if (ext && !['md', 'txt', 'json', 'gitignore', 'yml', 'yaml'].includes(ext)) {
            acc[ext] = (acc[ext] || 0) + 1;
          }
          return acc;
        }, {} as Record<string, number>);
        
        // Get most common file extensions as tech stack
        const techStack = Object.entries(fileExtensions)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 5)
          .map(([ext]) => {
            const langMap: Record<string, string> = {
              'js': 'JavaScript',
              'ts': 'TypeScript',
              'py': 'Python',
              'java': 'Java',
              'c': 'C',
              'cpp': 'C++',
              'cs': 'C#',
              'go': 'Go',
              'rb': 'Ruby',
              'php': 'PHP',
              'html': 'HTML',
              'css': 'CSS',
              'jsx': 'React',
              'tsx': 'React with TypeScript',
              'vue': 'Vue.js',
              'rs': 'Rust',
              'swift': 'Swift',
              'kt': 'Kotlin',
            };
            return langMap[ext] || ext.toUpperCase();
          });
        
        // Simple project description
        projectAnalysis = {
          name: repoName,
          description: `GitHub repository imported from ${owner}/${repoName}`,
          techStack: techStack,
          keyFeatures: ["Repository imported from GitHub", "Detailed analysis available after post generation"],
        };
      }
      
      // Create project in storage
      const project = await storage.createProject({
        name: projectAnalysis.name || repoName,
        description: projectAnalysis.description || `GitHub repository imported from ${owner}/${repoName}`,
        techStack: projectAnalysis.techStack || [],
        keyFeatures: projectAnalysis.keyFeatures || [],
        userId: user.id,
        fileCount: allFiles.length,
        username: username || user.username,
        email: email || user.email,
      });
      
      // Clean up the temporary directory
      fs.rmSync(tempDir, { recursive: true, force: true });
      
      res.status(200).json({
        message: "GitHub repository processed successfully",
        projectId: project.id,
      });
    } catch (error: any) {
      console.error("Error processing GitHub repository:", error);
      res.status(500).send(`Error processing GitHub repository: ${error?.message || "Unknown error"}`);
    }
  });

  // Get recent projects
  app.get("/api/projects/recent", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 6; // Show more projects by default
      
      // Get all user projects instead of just recent ones to ensure all projects are displayed
      const projects = await storage.getUserProjects(userId);
      
      // Sort by creation date descending (newest first)
      projects.sort((a, b) => {
        const dateA = new Date(a.createdAt).getTime();
        const dateB = new Date(b.createdAt).getTime();
        return dateB - dateA;
      });
      
      // Take only the requested number
      const recentProjects = projects.slice(0, limit);
      
      // Format projects for UI display with more details and correct date handling
      const formattedProjects = recentProjects.map(project => {
        // Determine primary language from tech stack if available
        let primaryLanguage = "Unknown";
        if (project.techStack && project.techStack.length > 0) {
          primaryLanguage = project.techStack[0];
        }
        
        // Format the date for display
        let createdAtFormatted = '';
        if (project.createdAt) {
          if (typeof project.createdAt === 'string') {
            createdAtFormatted = new Date(project.createdAt).toISOString();
          } else {
            createdAtFormatted = project.createdAt.toISOString();
          }
        }
        
        return {
          id: project.id,
          name: project.name,
          description: project.description,
          techStack: project.techStack || [],
          fileCount: project.fileCount,
          primaryLanguage,
          createdAt: createdAtFormatted,
          repoUrl: project.repoUrl
        };
      });
      
      res.json(formattedProjects);
    } catch (error) {
      console.error("Error fetching recent projects:", error);
      res.status(500).send("Error fetching recent projects");
    }
  });
}
