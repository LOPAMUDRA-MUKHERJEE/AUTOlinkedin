import { User, InsertUser, Project, InsertProject, Post, PostVersion } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateLastLogin(userId: number): Promise<void>;
  getAllUsers(): Promise<Omit<User, "password">[]>;
  getMarketingSubscribers(): Promise<Pick<User, "id" | "email" | "username">[]>;
  
  // Project methods
  getProject(id: string): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  getUserProjects(userId: number): Promise<Project[]>;
  getRecentProjects(userId: number, limit?: number): Promise<Project[]>;
  
  // Post methods
  createPost(projectId: string, content: string, author: string, headline?: string): Promise<Post>;
  getPostByProjectId(projectId: string): Promise<Post | undefined>;
  savePostVersion(postId: string, content: string): Promise<PostVersion>;
  getPostVersions(postId: string): Promise<PostVersion[]>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private projects: Map<string, Project>;
  private posts: Map<string, Post>;
  private postVersions: Map<string, PostVersion[]>;
  
  sessionStore: session.SessionStore;
  private userId: number;
  private projectId: number;
  private postId: number;
  private versionId: number;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.posts = new Map();
    this.postVersions = new Map();
    
    const MemoryStore = createMemoryStore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // Prune expired entries every 24h
      ttl: 30 * 24 * 60 * 60 * 1000, // Keep sessions for 30 days
    });
    
    this.userId = 1;
    this.projectId = 1;
    this.postId = 1;
    this.versionId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email?.toLowerCase() === email.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async updateLastLogin(userId: number): Promise<void> {
    const user = await this.getUser(userId);
    if (user) {
      user.lastLoginAt = new Date();
      this.users.set(userId, user);
    }
  }
  
  async getAllUsers(): Promise<Omit<User, "password">[]> {
    return Array.from(this.users.values()).map(({ password, ...user }) => user);
  }
  
  async getMarketingSubscribers(): Promise<Pick<User, "id" | "email" | "username">[]> {
    return Array.from(this.users.values())
      .filter(user => user.marketingConsent)
      .map(({ id, email, username }) => ({ id, email, username }));
  }
  
  // Project methods
  async getProject(id: string): Promise<Project | undefined> {
    return this.projects.get(id);
  }
  
  async createProject(project: InsertProject): Promise<Project> {
    const id = `proj_${this.projectId++}`;
    const newProject: Project = { ...project, id, createdAt: new Date() };
    this.projects.set(id, newProject);
    return newProject;
  }
  
  async getUserProjects(userId: number): Promise<Project[]> {
    return Array.from(this.projects.values())
      .filter(project => project.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async getRecentProjects(userId: number, limit: number = 3): Promise<Project[]> {
    return (await this.getUserProjects(userId)).slice(0, limit);
  }
  
  // Post methods
  async createPost(projectId: string, content: string, author: string, headline?: string): Promise<Post> {
    const id = `post_${this.postId++}`;
    const post: Post = { 
      id, 
      projectId, 
      content, 
      author, 
      headline, 
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.posts.set(id, post);
    
    // Create initial version
    this.savePostVersion(id, content);
    
    return post;
  }
  
  async getPostByProjectId(projectId: string): Promise<Post | undefined> {
    return Array.from(this.posts.values()).find(
      post => post.projectId === projectId
    );
  }
  
  async savePostVersion(postId: string, content: string): Promise<PostVersion> {
    const post = Array.from(this.posts.values()).find(p => p.id === postId);
    if (!post) {
      throw new Error("Post not found");
    }
    
    // Update the post with the new content
    post.content = content;
    post.updatedAt = new Date();
    this.posts.set(postId, post);
    
    // Create a new version
    const id = `ver_${this.versionId++}`;
    const version: PostVersion = {
      id,
      postId,
      content,
      createdAt: new Date()
    };
    
    // Add to versions map
    const versions = this.postVersions.get(postId) || [];
    versions.push(version);
    this.postVersions.set(postId, versions);
    
    return version;
  }
  
  async getPostVersions(postId: string): Promise<PostVersion[]> {
    return this.postVersions.get(postId) || [];
  }
}

export const storage = new MemStorage();
