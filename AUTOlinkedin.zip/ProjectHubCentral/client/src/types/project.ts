// Project details after analysis
export interface ProjectDetails {
  id: string;
  name: string;
  description?: string;
  userId: number;
  repoUrl?: string;
  createdAt: Date;
  techStack?: string[];
  keyFeatures?: string[];
  fileCount?: number;
  primaryLanguage?: string;
}

// LinkedIn post information
export interface Post {
  id: string;
  projectId: string;
  content: string;
  headline?: string;
  author: string;
  createdAt: Date;
}

// Post version history
export interface PostVersion {
  id: string;
  postId: string;
  content: string;
  createdAt: Date;
}

// Chat message format for AI assistant
export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

// AI chat response
export interface ChatResponse {
  message: string;
  suggestedChanges?: string;
}