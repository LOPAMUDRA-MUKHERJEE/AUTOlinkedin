import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";

export default function AuthPage() {
  const [location, setLocation] = useLocation();
  const { user, isLoading, loginMutation, registerMutation } = useAuth();
  const [activeTab, setActiveTab] = useState<"login" | "register">("login");
  
  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      setLocation("/");
    }
  }, [user, setLocation]);
  
  // Login form schema
  const loginSchema = z.object({
    username: z.string().min(3, "Username must be at least 3 characters"),
    password: z.string().min(6, "Password must be at least 6 characters"),
  });
  
  type LoginFormValues = z.infer<typeof loginSchema>;
  
  // Register form schema
  const registerSchema = z.object({
    username: z.string().min(3, "Username must be at least 3 characters"),
    email: z.string().email("Please enter a valid email address"),
    password: z.string().min(6, "Password must be at least 6 characters"),
    confirmPassword: z.string(),
  }).refine(data => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });
  
  type RegisterFormValues = z.infer<typeof registerSchema>;
  
  // Login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });
  
  // Register form
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  });
  
  // Handle login form submission
  const onLoginSubmit = (data: LoginFormValues) => {
    loginMutation.mutate(data);
  };
  
  // Handle register form submission
  const onRegisterSubmit = (data: RegisterFormValues) => {
    const { confirmPassword, ...registerData } = data;
    registerMutation.mutate(registerData);
  };
  
  return (
    <div className="min-h-screen flex">
      {/* Left side - Form */}
      <div className="flex-1 flex items-center justify-center p-8 bg-gradient-to-r from-gray-50 to-white">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-purple-600 rounded-xl mx-auto mb-4 flex items-center justify-center">
              <i className="ri-linkedin-box-fill text-3xl text-white"></i>
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent mb-3">AUTOlinkedin</h1>
            <p className="text-gray-600 text-lg">
              Sign in to create impactful LinkedIn posts
            </p>
          </div>
          
          <Tabs 
            value={activeTab} 
            onValueChange={(value) => setActiveTab(value as "login" | "register")}
            className="w-full"
          >
            <TabsList className="grid w-full grid-cols-2 mb-8 bg-gray-100 p-1 rounded-lg border overflow-hidden">
              <TabsTrigger 
                className="data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-md rounded-md py-3 font-medium text-gray-600 flex justify-center items-center" 
                value="login"
              >
                <span className="flex items-center justify-center">
                  <i className="ri-login-circle-line mr-2"></i> Login
                </span>
              </TabsTrigger>
              <TabsTrigger 
                className="data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-md rounded-md py-3 font-medium text-gray-600 flex justify-center items-center" 
                value="register"
              >
                <span className="flex items-center justify-center">
                  <i className="ri-user-add-line mr-2"></i> Register
                </span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="login">
              <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-username" className="text-gray-700 font-medium">Username</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                      <i className="ri-user-3-line"></i>
                    </div>
                    <Input
                      id="login-username"
                      type="text"
                      className="pl-10 py-6 bg-gray-50 border-gray-200 focus:ring-primary/50 focus:border-primary"
                      placeholder="Enter your username"
                      {...loginForm.register("username")}
                    />
                  </div>
                  {loginForm.formState.errors.username && (
                    <p className="text-sm text-red-500 flex items-center">
                      <i className="ri-error-warning-line mr-1"></i>
                      {loginForm.formState.errors.username.message}
                    </p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="login-password" className="text-gray-700 font-medium">Password</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                      <i className="ri-lock-2-line"></i>
                    </div>
                    <Input
                      id="login-password"
                      type="password"
                      className="pl-10 py-6 bg-gray-50 border-gray-200 focus:ring-primary/50 focus:border-primary"
                      placeholder="Enter your password"
                      {...loginForm.register("password")}
                    />
                  </div>
                  {loginForm.formState.errors.password && (
                    <p className="text-sm text-red-500 flex items-center">
                      <i className="ri-error-warning-line mr-1"></i>
                      {loginForm.formState.errors.password.message}
                    </p>
                  )}
                </div>
                
                {loginMutation.isError && (
                  <div className="p-4 bg-red-50 border border-red-200 rounded-md text-sm text-red-600 flex items-start">
                    <i className="ri-error-warning-fill text-red-500 mr-3 text-lg mt-0.5"></i>
                    <div>
                      <h4 className="font-medium text-red-700 mb-1">Login Failed</h4>
                      <p>{loginMutation.error.message || "Your login attempt was unsuccessful. Please check your credentials and try again."}</p>
                    </div>
                  </div>
                )}
                
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-700 text-white font-medium py-6 transition-all shadow-md hover:shadow-lg"
                  disabled={loginMutation.isPending}
                >
                  {loginMutation.isPending ? (
                    <span className="flex items-center justify-center">
                      <i className="ri-loader-4-line animate-spin mr-2"></i> Logging in...
                    </span>
                  ) : (
                    <span className="flex items-center justify-center">
                      <i className="ri-login-box-line mr-2"></i> Login
                    </span>
                  )}
                </Button>
              </form>
            </TabsContent>
            
            <TabsContent value="register">
              <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="register-username" className="text-gray-700 font-medium">Username</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                      <i className="ri-user-3-line"></i>
                    </div>
                    <Input
                      id="register-username"
                      type="text"
                      className="pl-10 py-6 bg-gray-50 border-gray-200 focus:ring-primary/50 focus:border-primary"
                      placeholder="Choose a username"
                      {...registerForm.register("username")}
                    />
                  </div>
                  {registerForm.formState.errors.username && (
                    <p className="text-sm text-red-500 flex items-center">
                      <i className="ri-error-warning-line mr-1"></i>
                      {registerForm.formState.errors.username.message}
                    </p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="register-email" className="text-gray-700 font-medium">Email</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                      <i className="ri-mail-line"></i>
                    </div>
                    <Input
                      id="register-email"
                      type="email"
                      className="pl-10 py-6 bg-gray-50 border-gray-200 focus:ring-primary/50 focus:border-primary"
                      placeholder="Enter your email"
                      {...registerForm.register("email")}
                    />
                  </div>
                  {registerForm.formState.errors.email && (
                    <p className="text-sm text-red-500 flex items-center">
                      <i className="ri-error-warning-line mr-1"></i>
                      {registerForm.formState.errors.email.message}
                    </p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="register-password" className="text-gray-700 font-medium">Password</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                      <i className="ri-lock-2-line"></i>
                    </div>
                    <Input
                      id="register-password"
                      type="password"
                      className="pl-10 py-6 bg-gray-50 border-gray-200 focus:ring-primary/50 focus:border-primary"
                      placeholder="Create a password"
                      {...registerForm.register("password")}
                    />
                  </div>
                  {registerForm.formState.errors.password && (
                    <p className="text-sm text-red-500 flex items-center">
                      <i className="ri-error-warning-line mr-1"></i>
                      {registerForm.formState.errors.password.message}
                    </p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="register-confirm-password" className="text-gray-700 font-medium">Confirm Password</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400">
                      <i className="ri-lock-password-line"></i>
                    </div>
                    <Input
                      id="register-confirm-password"
                      type="password"
                      className="pl-10 py-6 bg-gray-50 border-gray-200 focus:ring-primary/50 focus:border-primary"
                      placeholder="Confirm your password"
                      {...registerForm.register("confirmPassword")}
                    />
                  </div>
                  {registerForm.formState.errors.confirmPassword && (
                    <p className="text-sm text-red-500 flex items-center">
                      <i className="ri-error-warning-line mr-1"></i>
                      {registerForm.formState.errors.confirmPassword.message}
                    </p>
                  )}
                </div>
                
                {registerMutation.isError && (
                  <div className="p-4 bg-red-50 border border-red-200 rounded-md text-sm text-red-600 flex items-start">
                    <i className="ri-error-warning-fill text-red-500 mr-3 text-lg mt-0.5"></i>
                    <div>
                      <h4 className="font-medium text-red-700 mb-1">Registration Failed</h4>
                      <p>{registerMutation.error.message || "Your account couldn't be created. The username might already be taken or there may be a server issue."}</p>
                    </div>
                  </div>
                )}
                
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-700 text-white font-medium py-6 transition-all shadow-md hover:shadow-lg"
                  disabled={registerMutation.isPending}
                >
                  {registerMutation.isPending ? (
                    <span className="flex items-center justify-center">
                      <i className="ri-loader-4-line animate-spin mr-2"></i> Creating account...
                    </span>
                  ) : (
                    <span className="flex items-center justify-center">
                      <i className="ri-user-add-line mr-2"></i> Create Account
                    </span>
                  )}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      
      {/* Right side - Hero */}
      <div className="hidden lg:flex lg:flex-1 bg-gradient-to-br from-primary via-purple-700 to-indigo-800 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-full h-full opacity-10">
          <div className="absolute top-[10%] right-[10%] w-64 h-64 rounded-full bg-white/20 blur-3xl"></div>
          <div className="absolute bottom-[20%] left-[5%] w-96 h-96 rounded-full bg-indigo-300/20 blur-3xl"></div>
        </div>
        <div className="flex flex-col justify-center px-16 text-white relative z-10 max-w-2xl">
          <h2 className="text-4xl font-bold mb-6 leading-tight">
            Showcase Your <span className="text-indigo-200">Coding Projects</span> on LinkedIn
          </h2>
          <p className="text-white/90 text-lg mb-10 leading-relaxed">
            AUTOlinkedin analyzes your code and creates professional LinkedIn posts that highlight your projects, 
            skills, and achievements. Stand out to recruiters and peers.
          </p>
          <div className="space-y-6">
            <div className="flex items-start group">
              <div className="rounded-full bg-white/10 p-3 mr-4 backdrop-blur-sm shadow-lg transition-all duration-300 group-hover:bg-white/20">
                <i className="ri-upload-cloud-line text-xl"></i>
              </div>
              <div>
                <h3 className="font-semibold text-lg text-white group-hover:text-indigo-200 transition-colors duration-300">Upload Your Code</h3>
                <p className="text-white/80">
                  Upload project files or import directly from GitHub repositories
                </p>
              </div>
            </div>
            <div className="flex items-start group">
              <div className="rounded-full bg-white/10 p-3 mr-4 backdrop-blur-sm shadow-lg transition-all duration-300 group-hover:bg-white/20">
                <i className="ri-code-box-line text-xl"></i>
              </div>
              <div>
                <h3 className="font-semibold text-lg text-white group-hover:text-indigo-200 transition-colors duration-300">Smart Code Analysis</h3>
                <p className="text-white/80">
                  Our system analyzes your code to identify technologies and key project features
                </p>
              </div>
            </div>
            <div className="flex items-start group">
              <div className="rounded-full bg-white/10 p-3 mr-4 backdrop-blur-sm shadow-lg transition-all duration-300 group-hover:bg-white/20">
                <i className="ri-linkedin-box-line text-xl"></i>
              </div>
              <div>
                <h3 className="font-semibold text-lg text-white group-hover:text-indigo-200 transition-colors duration-300">Professional LinkedIn Posts</h3>
                <p className="text-white/80">
                  Generate customized content that showcases your skills to potential employers
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}