import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";

export default function HomePage() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();

  const handleStartNewProject = () => {
    setLocation("/upload");
  };

  const handleContinueProject = (projectId: string) => {
    setLocation(`/analyze/${projectId}`);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        {/* Dashboard Header */}
        <div className="relative overflow-hidden bg-gradient-to-r from-primary via-purple-700 to-indigo-800 rounded-xl p-8 mb-10 shadow-lg">
          <div className="absolute top-0 right-0 w-full h-full opacity-10">
            <div className="absolute top-[10%] right-[10%] w-64 h-64 rounded-full bg-white/20 blur-3xl"></div>
            <div className="absolute bottom-[20%] left-[10%] w-80 h-80 rounded-full bg-indigo-300/20 blur-3xl"></div>
          </div>
          
          <div className="relative z-10 max-w-3xl">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-3">
              Welcome to <span className="text-indigo-200">AUTOlinkedin</span>, {user?.username || "User"}!
            </h2>
            <p className="text-white/90 text-lg mb-6">
              Generate professional LinkedIn posts that showcase your coding skills and projects to potential employers and connections.
            </p>
            <Button 
              onClick={handleStartNewProject} 
              className="bg-white text-primary hover:bg-white/90 transition-all duration-200 font-medium shadow-md hover:shadow-lg"
            >
              <i className="ri-add-line mr-2"></i>
              Start New Project
            </Button>
          </div>
        </div>
        
        {/* Main Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <Card className="bg-gradient-to-br from-primary via-purple-700 to-indigo-800 shadow-lg relative overflow-hidden border-0">
            <div className="absolute top-0 right-0 w-full h-full opacity-10">
              <div className="absolute top-[10%] right-[10%] w-48 h-48 rounded-full bg-white/20 blur-2xl"></div>
              <div className="absolute bottom-[15%] left-[10%] w-64 h-64 rounded-full bg-indigo-300/20 blur-2xl"></div>
            </div>
            
            <CardHeader className="text-white pb-2 relative z-10">
              <div className="flex items-center mb-2">
                <CardTitle className="text-xl font-bold flex items-center">
                  <i className="ri-lightbulb-flash-line text-white text-xl mr-3"></i>
                  Tips for Better Results
                </CardTitle>
              </div>
              <CardDescription className="text-white/80">
                Improve your project analysis with these recommendations
              </CardDescription>
            </CardHeader>
            
            <CardContent className="text-white/90 pb-4 relative z-10">
              <ul className="mt-3 space-y-2 text-sm pl-2">
                <li className="group">
                  <span className="flex items-center group-hover:text-white transition-colors duration-200">
                    <i className="ri-checkbox-circle-line text-green-300 mr-2"></i>
                    Include a detailed README.md file with project overview and features
                  </span>
                </li>
                <li className="group">
                  <span className="flex items-center group-hover:text-white transition-colors duration-200">
                    <i className="ri-checkbox-circle-line text-green-300 mr-2"></i>
                    Add proper comments and documentation to your code files
                  </span>
                </li>
                <li className="group">
                  <span className="flex items-center group-hover:text-white transition-colors duration-200">
                    <i className="ri-checkbox-circle-line text-green-300 mr-2"></i>
                    Include dependency files (package.json, requirements.txt, etc.)
                  </span>
                </li>
                <li className="group">
                  <span className="flex items-center group-hover:text-white transition-colors duration-200">
                    <i className="ri-checkbox-circle-line text-green-300 mr-2"></i>
                    Use descriptive names for functions, classes, and variables
                  </span>
                </li>
                <li className="group">
                  <span className="flex items-center group-hover:text-white transition-colors duration-200">
                    <i className="ri-checkbox-circle-line text-green-300 mr-2"></i>
                    Add appropriate error handling and input validation
                  </span>
                </li>
              </ul>
            </CardContent>
            
            <CardFooter className="relative z-10">
              <Button 
                className="w-full bg-white text-primary hover:bg-white/90 transition-all duration-200 font-medium shadow-md"
                onClick={handleStartNewProject}
              >
                <i className="ri-add-line mr-2"></i>
                Start New Project
              </Button>
            </CardFooter>
          </Card>
          
          <Card className="border shadow-sm hover:shadow-md transition-all duration-200">
            <CardHeader className="pb-4 border-b">
              <div className="flex items-center mb-2">
                <CardTitle className="text-xl font-bold flex items-center">
                  <i className="ri-flow-chart text-primary text-xl mr-3"></i>
                  How It Works
                </CardTitle>
              </div>
              <CardDescription>
                Three simple steps to create your professional LinkedIn post
              </CardDescription>
            </CardHeader>
            
            <CardContent className="pt-6 pb-4">
              <div className="space-y-6">
                <div className="flex items-start group hover:bg-gray-50 p-2 rounded-md -mx-2 transition-colors duration-200">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 text-primary font-bold flex items-center justify-center mr-4 shadow-sm">
                    1
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-1 flex items-center">
                      <i className="ri-upload-cloud-line text-primary mr-2"></i>
                      Upload
                    </h4>
                    <p className="text-sm text-gray-600">Upload your code files directly or import from a GitHub repository</p>
                  </div>
                </div>
                
                <div className="flex items-start group hover:bg-gray-50 p-2 rounded-md -mx-2 transition-colors duration-200">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 text-primary font-bold flex items-center justify-center mr-4 shadow-sm">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-1 flex items-center">
                      <i className="ri-code-box-line text-primary mr-2"></i>
                      Analyze
                    </h4>
                    <p className="text-sm text-gray-600">Our AI analyzes your project structure, technologies, and features</p>
                  </div>
                </div>
                
                <div className="flex items-start group hover:bg-gray-50 p-2 rounded-md -mx-2 transition-colors duration-200">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 text-primary font-bold flex items-center justify-center mr-4 shadow-sm">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-1 flex items-center">
                      <i className="ri-linkedin-box-line text-primary mr-2"></i>
                      Generate
                    </h4>
                    <p className="text-sm text-gray-600">Review, customize, and copy your professional LinkedIn post</p>
                  </div>
                </div>
              </div>
            </CardContent>
            
            <CardFooter className="pt-2 border-t">
              <Button 
                className="w-full bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-700 text-white transition-all duration-200 font-medium"
                onClick={handleStartNewProject}
              >
                <i className="ri-rocket-line mr-2"></i>
                Get Started Now
              </Button>
            </CardFooter>
          </Card>
        </div>
        
        {/* FAQs */}
        <div className="mb-10">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-gray-800 flex items-center">
              <i className="ri-question-line text-primary mr-2"></i>
              Frequently Asked Questions
            </h3>
            <div className="h-px flex-grow bg-gray-200 ml-4"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="border border-gray-200 hover:border-primary/30 transition-colors duration-200 hover:shadow-md">
              <CardHeader className="pb-2 bg-gray-50 rounded-t-lg border-b">
                <CardTitle className="text-base font-medium flex items-center">
                  <i className="ri-code-box-line text-primary mr-2"></i>
                  How does AUTOlinkedin analyze my code?
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-sm text-gray-600 leading-relaxed">
                  AUTOlinkedin examines your project files, detects technologies used, and analyzes structure to identify key features. 
                  The analysis runs locally to ensure reliability even when API services are unavailable.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border border-gray-200 hover:border-primary/30 transition-colors duration-200 hover:shadow-md">
              <CardHeader className="pb-2 bg-gray-50 rounded-t-lg border-b">
                <CardTitle className="text-base font-medium flex items-center">
                  <i className="ri-edit-line text-primary mr-2"></i>
                  Can I customize the generated LinkedIn post?
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-sm text-gray-600 leading-relaxed">
                  Yes! After generation, you can edit the post directly, adjust its tone, focus on specific features, 
                  or modify any content before copying it to LinkedIn. You can also choose different tones and formats.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border border-gray-200 hover:border-primary/30 transition-colors duration-200 hover:shadow-md">
              <CardHeader className="pb-2 bg-gray-50 rounded-t-lg border-b">
                <CardTitle className="text-base font-medium flex items-center">
                  <i className="ri-shield-check-line text-primary mr-2"></i>
                  Is my code stored or shared?
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-sm text-gray-600 leading-relaxed">
                  Your code is analyzed locally and not stored permanently. We only save the analysis results 
                  and generated content. Your intellectual property remains your own, and your code is not shared with third parties.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border border-gray-200 hover:border-primary/30 transition-colors duration-200 hover:shadow-md">
              <CardHeader className="pb-2 bg-gray-50 rounded-t-lg border-b">
                <CardTitle className="text-base font-medium flex items-center">
                  <i className="ri-github-fill text-primary mr-2"></i>
                  Can I import from private GitHub repositories?
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <p className="text-sm text-gray-600 leading-relaxed">
                  Currently, AUTOlinkedin can only import from public GitHub repositories. To use private repositories, 
                  download your code and upload the files directly.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
