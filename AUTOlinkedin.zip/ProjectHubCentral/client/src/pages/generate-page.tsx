import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { ProjectDetails, Post } from "@/types/project";
import { useAuth } from "@/hooks/use-auth";
import AIChat from "@/components/AIChat";

type Tone = "professional" | "casual" | "technical" | "enthusiastic";
type Length = "standard" | "in-depth";
type Audience = "recruiters" | "peers" | "professors" | "industry";

interface GeneratePageProps {
  projectId: string;
}

export default function GeneratePage({ projectId }: GeneratePageProps) {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [selectedTone, setSelectedTone] = useState<Tone>("professional");
  const [selectedLength, setSelectedLength] = useState<Length>("standard");
  const [selectedAudience, setSelectedAudience] = useState<Audience>("recruiters");
  const [postContent, setPostContent] = useState<string>("");
  const [isEditing, setIsEditing] = useState(false);
  const [editedPost, setEditedPost] = useState<string>("");
  const [previewDescription, setPreviewDescription] = useState<string>("");

  // Fetch project details
  const {
    data: projectDetails,
    isLoading: isLoadingProject,
    error: projectError,
  } = useQuery<ProjectDetails>({
    queryKey: ["/api/projects/details", projectId],
    enabled: !!projectId,
  });

  // Fetch current post if it exists
  const {
    data: post,
    isLoading: isLoadingPost,
    refetch: refetchPost,
  } = useQuery<Post>({
    queryKey: ["/api/projects/current-post", projectId],
    enabled: !!projectId,
  });

  // Redirect back to upload if no project ID or error
  useEffect(() => {
    if (!projectId || projectError) {
      setLocation("/upload");
    }
  }, [projectId, projectError, setLocation]);

  // Update local state when post data is fetched
  useEffect(() => {
    if (post?.content) {
      setPostContent(post.content);
      setEditedPost(post.content);
    }
  }, [post]);

  // Update preview description when parameters change
  useEffect(() => {
    const toneDescriptions = {
      professional: "Formal language, business-focused",
      casual: "Conversational, friendly tone",
      technical: "Detailed technical information",
      enthusiastic: "Energetic, passionate language"
    };
    
    const lengthDescriptions = {
      standard: "150-200 words, concise",
      "in-depth": "250-350 words, detailed"
    };
    
    const audienceDescriptions = {
      recruiters: "Hiring managers, emphasizes skills",
      peers: "Fellow developers, technical focus",
      professors: "Academic audience, educational emphasis",
      industry: "Industry professionals, business value"
    };
    
    setPreviewDescription(
      `${toneDescriptions[selectedTone]} • ${lengthDescriptions[selectedLength]} • ${audienceDescriptions[selectedAudience]}`
    );
  }, [selectedTone, selectedLength, selectedAudience]);

  // Generate post mutation
  const generatePostMutation = useMutation({
    mutationFn: async (preferences: {
      tone: Tone;
      length: Length;
      audience: Audience;
    }) => {
      return await apiRequest("POST", "/api/projects/generate-post", {
        ...preferences,
        projectId: projectId,
      });
    },
    onSuccess: () => {
      toast({
        title: "LinkedIn post generated",
        description: "Your post has been created based on your project and preferences.",
      });
      refetchPost();
    },
    onError: (error: Error) => {
      toast({
        title: "Generation failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Save edited post
  const savePostMutation = useMutation({
    mutationFn: async (content: string) => {
      return await apiRequest("POST", "/api/projects/save-post-version", {
        projectId: projectId,
        postContent: content,
      });
    },
    onSuccess: () => {
      toast({
        title: "Post saved",
        description: "Your edited post has been saved.",
      });
      setPostContent(editedPost);
      setIsEditing(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Save failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGeneratePost = () => {
    if (!projectDetails) {
      toast({
        title: "No project selected",
        description: "Please upload a project first",
        variant: "destructive",
      });
      return;
    }

    generatePostMutation.mutate({
      tone: selectedTone,
      length: selectedLength,
      audience: selectedAudience,
    });
  };

  const handleEditPost = () => {
    setIsEditing(true);
    setEditedPost(postContent);
  };

  const handleSaveEdit = () => {
    savePostMutation.mutate(editedPost);
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedPost(postContent);
  };

  const handlePostUpdated = (updatedPost: string) => {
    setPostContent(updatedPost);
    setEditedPost(updatedPost);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-6">
        {/* Page Header */}
        <div className="mb-8">
          <h2 className="text-2xl font-semibold text-secondary-600 mb-2">
            Generate LinkedIn Post
          </h2>
          <p className="text-secondary-500">
            Customize your LinkedIn post and make it shine.
          </p>
        </div>
        
        {/* Step indicator */}
        <div className="flex items-center justify-center mb-8">
          <div className="flex items-center">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-success-500 text-white font-bold">
              ✓
            </div>
            <div className="ml-2 font-medium text-success-500">Upload</div>
          </div>
          <div className="w-16 h-1 mx-2 bg-success-500"></div>
          <div className="flex items-center">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-success-500 text-white font-bold">
              ✓
            </div>
            <div className="ml-2 font-medium text-success-500">Analyze</div>
          </div>
          <div className="w-16 h-1 mx-2 bg-success-500"></div>
          <div className="flex items-center">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-white font-bold">
              3
            </div>
            <div className="ml-2 font-medium text-primary">Generate</div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Post preferences */}
          <div className="lg:col-span-1 bg-white rounded-lg shadow-sm p-6 h-fit">
            <h3 className="text-lg font-semibold text-secondary-600 mb-4 flex items-center">
              <i className="ri-settings-line mr-2 text-primary"></i>
              Post Preferences
            </h3>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-secondary-500 mb-2">
                Tone
              </label>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant={selectedTone === "professional" ? "default" : "outline"}
                  className={selectedTone === "professional" ? "bg-primary text-white" : ""}
                  onClick={() => setSelectedTone("professional")}
                >
                  Professional
                </Button>
                <Button
                  variant={selectedTone === "casual" ? "default" : "outline"}
                  className={selectedTone === "casual" ? "bg-primary text-white" : ""}
                  onClick={() => setSelectedTone("casual")}
                >
                  Casual
                </Button>
                <Button
                  variant={selectedTone === "technical" ? "default" : "outline"}
                  className={selectedTone === "technical" ? "bg-primary text-white" : ""}
                  onClick={() => setSelectedTone("technical")}
                >
                  Technical
                </Button>
                <Button
                  variant={selectedTone === "enthusiastic" ? "default" : "outline"}
                  className={selectedTone === "enthusiastic" ? "bg-primary text-white" : ""}
                  onClick={() => setSelectedTone("enthusiastic")}
                >
                  Enthusiastic
                </Button>
              </div>
            </div>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-secondary-500 mb-2">
                Length
              </label>
              <div className="flex space-x-2">
                <Button
                  variant={selectedLength === "standard" ? "default" : "outline"}
                  className={`flex-1 ${selectedLength === "standard" ? "bg-primary text-white" : ""}`}
                  onClick={() => setSelectedLength("standard")}
                >
                  Standard
                </Button>
                <Button
                  variant={selectedLength === "in-depth" ? "default" : "outline"}
                  className={`flex-1 ${selectedLength === "in-depth" ? "bg-primary text-white" : ""}`}
                  onClick={() => setSelectedLength("in-depth")}
                >
                  In-Depth
                </Button>
              </div>
            </div>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-secondary-500 mb-2">
                Target Audience
              </label>
              <Select 
                value={selectedAudience} 
                onValueChange={(value) => setSelectedAudience(value as Audience)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select audience" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recruiters">Recruiters</SelectItem>
                  <SelectItem value="peers">Peers</SelectItem>
                  <SelectItem value="professors">Professors</SelectItem>
                  <SelectItem value="industry">Industry professionals</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button
              className="w-full mt-4 bg-primary hover:bg-primary/90 text-white"
              onClick={handleGeneratePost}
              disabled={generatePostMutation.isPending}
            >
              {generatePostMutation.isPending ? (
                <>
                  <i className="ri-loader-4-line animate-spin mr-2"></i>
                  Generating...
                </>
              ) : (
                <>
                  <i className="ri-magic-line mr-2"></i>
                  Generate LinkedIn Post
                </>
              )}
            </Button>
            
            <div className="mt-4 text-xs text-neutral-500">
              <p className="font-medium">Current settings:</p>
              <p>{previewDescription}</p>
            </div>
            
            <div className="mt-6 pt-6 border-t border-neutral-200">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => setLocation(`/analyze/${projectId}`)}
              >
                <i className="ri-arrow-left-line mr-2"></i>
                Back to Analysis
              </Button>
            </div>
          </div>
          
          {/* Post preview */}
          <div className="lg:col-span-2 bg-white rounded-lg shadow-sm p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-secondary-600 flex items-center">
                <i className="ri-linkedin-box-fill mr-2 text-[#0A66C2]"></i>
                LinkedIn Post Preview
              </h3>
              
              {postContent && !isEditing && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleEditPost}
                >
                  <i className="ri-edit-line mr-2"></i>
                  Edit
                </Button>
              )}
              
              {isEditing && (
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCancelEdit}
                  >
                    Cancel
                  </Button>
                  <Button
                    size="sm"
                    className="bg-primary text-white"
                    onClick={handleSaveEdit}
                    disabled={savePostMutation.isPending}
                  >
                    {savePostMutation.isPending ? "Saving..." : "Save"}
                  </Button>
                </div>
              )}
            </div>
            
            {isLoadingPost || generatePostMutation.isPending ? (
              <div className="flex flex-col items-center justify-center py-16">
                <div className="w-12 h-12 border-4 border-t-primary border-neutral-200 rounded-full animate-spin mb-4"></div>
                <p className="text-neutral-500">
                  {generatePostMutation.isPending ? "Generating your post..." : "Loading post..."}
                </p>
              </div>
            ) : postContent ? (
              isEditing ? (
                <Textarea
                  className="min-h-[300px] font-medium leading-relaxed"
                  value={editedPost}
                  onChange={(e) => setEditedPost(e.target.value)}
                />
              ) : (
                <div className="rounded-md border p-4 min-h-[300px] whitespace-pre-wrap font-medium leading-relaxed">
                  {postContent}
                </div>
              )
            ) : (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mb-4">
                  <i className="ri-draft-line text-2xl text-neutral-400"></i>
                </div>
                <h4 className="text-lg font-medium text-secondary-600 mb-2">No post generated yet</h4>
                <p className="text-neutral-500 max-w-md mb-6">
                  Set your preferences and click "Generate LinkedIn Post" to create content based on your project.
                </p>
                <Button
                  className="bg-primary hover:bg-primary/90 text-white"
                  onClick={handleGeneratePost}
                >
                  <i className="ri-magic-line mr-2"></i>
                  Generate Post Now
                </Button>
              </div>
            )}
            
            {/* AI Chat Assistant */}
            {postContent && (
              <div className="mt-8 pt-6 border-t border-neutral-200">
                <AIChat
                  projectId={projectId}
                  currentPost={postContent}
                  onPostUpdated={handlePostUpdated}
                  disabled={isEditing || generatePostMutation.isPending}
                />
              </div>
            )}
            
            {/* Copy and Share buttons */}
            {postContent && !isEditing && (
              <div className="mt-6 flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    navigator.clipboard.writeText(postContent);
                    toast({
                      title: "Copied to clipboard",
                      description: "Your LinkedIn post has been copied to the clipboard.",
                    });
                  }}
                >
                  <i className="ri-clipboard-line mr-2"></i>
                  Copy to Clipboard
                </Button>
                <Button
                  className="flex-1 bg-[#0A66C2] hover:bg-[#0A66C2]/90 text-white"
                  onClick={() => {
                    const linkedInShareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent("https://www.linkedin.com/post")}`;
                    window.open(linkedInShareUrl, "_blank");
                  }}
                >
                  <i className="ri-linkedin-fill mr-2"></i>
                  Share on LinkedIn
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}