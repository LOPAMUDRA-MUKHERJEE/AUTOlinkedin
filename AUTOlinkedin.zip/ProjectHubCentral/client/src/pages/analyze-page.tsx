import { useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ProjectDetails } from "@/types/project";
import { useAuth } from "@/hooks/use-auth";

interface AnalyzePageProps {
  projectId: string;
}

export default function AnalyzePage({ projectId }: AnalyzePageProps) {
  const [, setLocation] = useLocation();
  const { user } = useAuth();

  // Fetch project details
  const {
    data: projectDetails,
    isLoading,
    error,
  } = useQuery<ProjectDetails>({
    queryKey: ["/api/projects/details", projectId],
    enabled: !!projectId,
  });

  // Redirect back to upload if no project ID or error
  useEffect(() => {
    if (!projectId || error) {
      setLocation("/upload");
    }
  }, [projectId, error, setLocation]);

  const handleContinue = () => {
    setLocation(`/generate/${projectId}`);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-6">
        {/* Page Header */}
        <div className="mb-8">
          <h2 className="text-2xl font-semibold text-secondary-600 mb-2">
            Project Analysis
          </h2>
          <p className="text-secondary-500">
            We've analyzed your project. Review the details before generating your LinkedIn post.
          </p>
        </div>
        
        {/* Step indicator */}
        <div className="flex items-center justify-center mb-8">
          <div className="flex items-center">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-success-500 text-white font-bold">
              ✓
            </div>
            <div className="ml-2 font-medium text-success-500">Upload</div>
          </div>
          <div className="w-16 h-1 mx-2 bg-success-500"></div>
          <div className="flex items-center">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-white font-bold">
              2
            </div>
            <div className="ml-2 font-medium text-primary">Analyze</div>
          </div>
          <div className="w-16 h-1 mx-2 bg-neutral-200"></div>
          <div className="flex items-center">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-neutral-200 text-neutral-500 font-bold">
              3
            </div>
            <div className="ml-2 font-medium text-neutral-500">Generate</div>
          </div>
        </div>
        
        {/* Project Analysis */}
        <div className="max-w-5xl mx-auto mb-8">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-10 bg-white rounded-lg shadow-sm p-6">
              <div className="w-12 h-12 border-4 border-t-primary border-neutral-200 rounded-full animate-spin mb-4"></div>
              <p className="text-neutral-500">Analyzing your project...</p>
            </div>
          ) : projectDetails ? (
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
              {/* Left side - Key Features */}
              <div className="md:col-span-2 bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-xl font-semibold text-secondary-800 mb-4 flex items-center">
                  <i className="ri-star-line mr-2 text-primary"></i>
                  Key Features
                </h3>
                
                <ul className="space-y-2 text-secondary-600">
                  {projectDetails.keyFeatures && projectDetails.keyFeatures.length > 0 ? (
                    projectDetails.keyFeatures.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <i className="ri-checkbox-circle-line text-primary mt-1 mr-2 flex-shrink-0"></i>
                        <span>{feature}</span>
                      </li>
                    ))
                  ) : (
                    <li className="flex items-start">
                      <i className="ri-information-line text-neutral-400 mt-1 mr-2 flex-shrink-0"></i>
                      <span className="text-neutral-500">No key features detected</span>
                    </li>
                  )}
                </ul>

                <div className="mt-6 pt-6 border-t border-neutral-200">
                  <h4 className="text-sm font-medium text-neutral-500 mb-3">Technologies</h4>
                  <div className="flex flex-wrap gap-2">
                    {projectDetails.techStack && projectDetails.techStack.length > 0 ? (
                      projectDetails.techStack.map((tech, index) => (
                        <Badge key={index} variant="outline" className="bg-neutral-100 border-neutral-200">
                          {tech}
                        </Badge>
                      ))
                    ) : (
                      <p className="text-neutral-500">No technologies detected</p>
                    )}
                  </div>
                </div>
              </div>
              
              {/* Right side - Project Summary */}
              <div className="md:col-span-3 bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-xl font-semibold text-secondary-800 mb-4 flex items-center">
                  <i className="ri-file-list-line mr-2 text-primary"></i>
                  Project Summary
                </h3>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium text-secondary-600">Project Name:</h4>
                    <p className="text-lg text-secondary-800">{projectDetails.name}</p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-secondary-600">File Count:</h4>
                    <p className="text-secondary-800">{projectDetails.fileCount || 0} files</p>
                  </div>
                  
                  {projectDetails.primaryLanguage && (
                    <div>
                      <h4 className="font-medium text-secondary-600">Primary Language:</h4>
                      <p className="text-secondary-800">{projectDetails.primaryLanguage}</p>
                    </div>
                  )}
                  
                  <div className="pt-4 border-t border-neutral-200">
                    <h4 className="font-medium text-secondary-600">Description:</h4>
                    <p className="text-secondary-700 mt-2 leading-relaxed">
                      {projectDetails.description || "No description available"}
                    </p>
                  </div>
                  
                  {projectDetails.repoUrl && (
                    <div className="pt-4 border-t border-neutral-200">
                      <h4 className="font-medium text-secondary-600">Source:</h4>
                      <p className="text-primary mt-1 break-all">
                        <i className="ri-github-fill mr-1"></i>
                        {projectDetails.repoUrl}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-10 bg-white rounded-lg shadow-sm">
              <div className="w-12 h-12 rounded-full bg-neutral-100 flex items-center justify-center mb-3">
                <i className="ri-error-warning-line text-2xl text-neutral-500"></i>
              </div>
              <p className="text-neutral-500">Project not found. Please try uploading again.</p>
              <Button 
                className="mt-4"
                onClick={() => setLocation("/upload")}
              >
                Back to Upload
              </Button>
            </div>
          )}
        </div>
        
        <div className="max-w-5xl mx-auto flex justify-between items-center">
          <Button 
            variant="outline"
            onClick={() => setLocation("/upload")}
          >
            <i className="ri-arrow-left-line mr-2"></i>
            Back to Upload
          </Button>
          
          <Button 
            className="bg-primary text-white"
            onClick={handleContinue}
            disabled={isLoading || !projectDetails}
          >
            Continue to Generation
            <i className="ri-arrow-right-line ml-2"></i>
          </Button>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}