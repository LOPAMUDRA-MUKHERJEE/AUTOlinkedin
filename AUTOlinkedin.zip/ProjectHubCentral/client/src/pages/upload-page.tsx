import { useState } from "react";
import { useLocation } from "wouter";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";

// Helper function to determine file icon based on file extension
function getFileIcon(fileName: string): string {
  const extension = fileName.split('.').pop()?.toLowerCase() || '';
  
  switch (extension) {
    case 'js':
      return 'code-line';
    case 'jsx':
      return 'code-line';
    case 'ts':
      return 'code-line';
    case 'tsx':
      return 'code-line';
    case 'py':
      return 'code-line';
    case 'java':
      return 'code-line';
    case 'html':
      return 'html5-line';
    case 'css':
      return 'css3-line';
    case 'json':
      return 'brackets-line';
    case 'md':
      return 'markdown-line';
    case 'jpg':
    case 'jpeg':
    case 'png':
    case 'gif':
    case 'svg':
      return 'image-line';
    case 'pdf':
      return 'file-pdf-line';
    case 'zip':
    case 'rar':
    case 'tar':
    case 'gz':
      return 'file-zip-line';
    case 'docx':
    case 'doc':
      return 'file-word-line';
    case 'xlsx':
    case 'xls':
      return 'file-excel-line';
    case 'pptx':
    case 'ppt':
      return 'file-ppt-line';
    default:
      return 'file-text-line';
  }
}

export default function UploadPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  
  const [selectedFiles, setSelectedFiles] = useState<FileList | null>(null);
  const [githubUrl, setGithubUrl] = useState("");
  const [projectName, setProjectName] = useState("");
  const [isUploading, setIsUploading] = useState(false);

  // Upload files mutation
  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await fetch("/api/projects/upload", {
        method: "POST",
        body: formData,
      });
      
      if (!res.ok) {
        const error = await res.text();
        throw new Error(error || "Failed to upload project");
      }
      
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Upload successful",
        description: "Your project has been uploaded and is ready for analysis.",
      });
      
      // Navigate to analyze page with project ID
      setLocation(`/analyze/${data.projectId}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
      setIsUploading(false);
    },
  });

  // Clone GitHub repo mutation
  const cloneRepoMutation = useMutation({
    mutationFn: async (data: { url: string; name: string }) => {
      const res = await apiRequest("POST", "/api/projects/clone", data);
      
      if (!res.ok) {
        const error = await res.text();
        throw new Error(error || "Failed to clone repository");
      }
      
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Repository cloned",
        description: "The GitHub repository has been cloned and is ready for analysis.",
      });
      
      // Navigate to analyze page with project ID
      setLocation(`/analyze/${data.projectId}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Clone failed",
        description: error.message,
        variant: "destructive",
      });
      setIsUploading(false);
    },
  });

  const handleFileUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedFiles || selectedFiles.length === 0) {
      toast({
        title: "No files selected",
        description: "Please select files to upload.",
        variant: "destructive",
      });
      return;
    }

    if (!projectName.trim()) {
      toast({
        title: "Project name required",
        description: "Please provide a name for your project.",
        variant: "destructive",
      });
      return;
    }
    
    setIsUploading(true);
    
    const formData = new FormData();
    formData.append("projectName", projectName);
    
    // Append all files to FormData
    for (let i = 0; i < selectedFiles.length; i++) {
      formData.append("files", selectedFiles[i]);
    }
    
    uploadMutation.mutate(formData);
  };

  const handleGithubClone = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!githubUrl.trim()) {
      toast({
        title: "Repository URL required",
        description: "Please enter a GitHub repository URL.",
        variant: "destructive",
      });
      return;
    }

    if (!projectName.trim()) {
      toast({
        title: "Project name required",
        description: "Please provide a name for your project.",
        variant: "destructive",
      });
      return;
    }
    
    // Validate GitHub URL format
    const githubRegex = /^https?:\/\/(www\.)?github\.com\/[\w-]+\/[\w-]+(\.git)?$/;
    if (!githubRegex.test(githubUrl)) {
      toast({
        title: "Invalid GitHub URL",
        description: "Please enter a valid GitHub repository URL (e.g., https://github.com/username/repo).",
        variant: "destructive",
      });
      return;
    }
    
    setIsUploading(true);
    cloneRepoMutation.mutate({ url: githubUrl, name: projectName });
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-6">
        {/* Page Header */}
        <div className="max-w-3xl mx-auto text-center mb-10">
          <div className="inline-block bg-primary/10 rounded-full px-4 py-2 text-primary text-sm font-medium mb-3">
            Step 1: Upload Your Project
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
            Share Your Code With The World
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Upload your project files or import from GitHub to start creating 
            a professional LinkedIn post that showcases your development skills.
          </p>
        </div>
        
        {/* Step indicator */}
        <div className="max-w-3xl mx-auto mb-10">
          <div className="relative flex items-center justify-between">
            {/* Progress bar background */}
            <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-full h-1 bg-gray-200 rounded"></div>
            
            {/* Active progress */}
            <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-1/6 h-1 bg-gradient-to-r from-primary to-purple-600 rounded"></div>
            
            {/* Step 1 */}
            <div className="relative z-10 flex flex-col items-center">
              <div className="w-10 h-10 flex items-center justify-center rounded-full bg-gradient-to-r from-primary to-purple-600 text-white font-bold shadow-md">
                1
              </div>
              <div className="mt-2 font-medium text-primary">Upload</div>
            </div>
            
            {/* Step 2 */}
            <div className="relative z-10 flex flex-col items-center">
              <div className="w-10 h-10 flex items-center justify-center rounded-full bg-white border-2 border-gray-200 text-gray-400 font-bold">
                2
              </div>
              <div className="mt-2 font-medium text-gray-400">Analyze</div>
            </div>
            
            {/* Step 3 */}
            <div className="relative z-10 flex flex-col items-center">
              <div className="w-10 h-10 flex items-center justify-center rounded-full bg-white border-2 border-gray-200 text-gray-400 font-bold">
                3
              </div>
              <div className="mt-2 font-medium text-gray-400">Generate</div>
            </div>
          </div>
        </div>
        
        {/* Upload form */}
        <div className="max-w-2xl mx-auto">
          <Tabs defaultValue="file-upload" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8 bg-gray-100 p-1 rounded-lg border overflow-hidden">
              <TabsTrigger 
                value="file-upload" 
                className="data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-sm rounded-md transition-all duration-200 py-3 font-medium flex justify-center items-center"
              >
                <span className="flex items-center justify-center">
                  <i className="ri-folder-upload-line mr-2"></i>
                  Upload Files
                </span>
              </TabsTrigger>
              <TabsTrigger 
                value="github" 
                className="data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-sm rounded-md transition-all duration-200 py-3 font-medium flex justify-center items-center"
              >
                <span className="flex items-center justify-center">
                  <i className="ri-github-fill mr-2"></i>
                  Import from GitHub
                </span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="file-upload">
              <Card className="border shadow-md hover:shadow-lg transition-all duration-200">
                <CardContent className="pt-6">
                  <form onSubmit={handleFileUpload} className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="project-name" className="text-sm font-medium flex items-center">
                        <i className="ri-edit-line text-primary mr-2"></i>
                        Project Name
                      </Label>
                      <div className="relative">
                        <Input
                          id="project-name"
                          placeholder="My Awesome Project"
                          value={projectName}
                          onChange={(e) => setProjectName(e.target.value)}
                          required
                          className="pl-10 border-gray-300 focus:border-primary focus:ring-1 focus:ring-primary"
                        />
                        <div className="absolute left-3 top-2.5 text-gray-400">
                          <i className="ri-code-box-line"></i>
                        </div>
                      </div>
                      <p className="text-xs text-gray-500 ml-1">
                        Choose a name that describes your project clearly
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="file-upload" className="text-sm font-medium flex items-center">
                        <i className="ri-folder-upload-line text-primary mr-2"></i>
                        Project Files
                      </Label>
                      <div className="border-2 border-dashed border-gray-300 hover:border-primary rounded-lg p-8 text-center bg-gray-50 transition-all duration-200 group">
                        <input
                          id="file-upload"
                          type="file"
                          multiple
                          className="hidden"
                          onChange={(e) => setSelectedFiles(e.target.files)}
                        />
                        
                        <label
                          htmlFor="file-upload"
                          className="cursor-pointer flex flex-col items-center justify-center"
                        >
                          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-all duration-200">
                            <i className="ri-upload-cloud-2-line text-3xl text-primary"></i>
                          </div>
                          <p className="text-gray-800 font-medium mb-2 group-hover:text-primary transition-colors duration-200">
                            Drag files here or click to browse
                          </p>
                          <p className="text-sm text-gray-500 max-w-xs mx-auto">
                            Supported formats: ZIP, JS, TS, PY, Java, HTML, CSS, JSON and more.
                            Include dependencies and README if possible.
                          </p>
                          
                          {selectedFiles && selectedFiles.length > 0 && (
                            <div className="mt-6 text-left w-full bg-white p-4 rounded-md border border-gray-200">
                              <div className="flex items-center justify-between mb-2">
                                <p className="text-sm font-medium text-gray-700 flex items-center">
                                  <i className="ri-file-list-3-line mr-2 text-primary"></i>
                                  Selected {selectedFiles.length} files
                                </p>
                                <p className="text-xs text-gray-500">
                                  Total size: {Array.from(selectedFiles).reduce((acc, file) => acc + file.size, 0) / 1024 < 1000 ? 
                                    `${(Array.from(selectedFiles).reduce((acc, file) => acc + file.size, 0) / 1024).toFixed(1)} KB` : 
                                    `${(Array.from(selectedFiles).reduce((acc, file) => acc + file.size, 0) / (1024 * 1024)).toFixed(1)} MB`}
                                </p>
                              </div>
                              <div className="max-h-40 overflow-y-auto pr-2">
                                <ul className="space-y-1.5 text-xs text-gray-700">
                                  {Array.from(selectedFiles).map((file, index) => (
                                    <li key={index} className="flex items-center rounded-md p-1.5 hover:bg-gray-50">
                                      <i className={`ri-file-${getFileIcon(file.name)} text-primary mr-2`}></i>
                                      <span className="truncate flex-1">{file.name}</span>
                                      <span className="text-gray-500 ml-2">{(file.size / 1024).toFixed(1)} KB</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            </div>
                          )}
                        </label>
                      </div>
                    </div>
                    
                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-700 text-white transition-all duration-200 font-medium py-6"
                      disabled={isUploading || !selectedFiles}
                    >
                      {isUploading ? (
                        <>
                          <i className="ri-loader-4-line animate-spin mr-2"></i>
                          Uploading your project...
                        </>
                      ) : (
                        <>
                          <i className="ri-upload-2-line mr-2"></i>
                          Upload Project and Continue
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="github">
              <Card className="border shadow-md hover:shadow-lg transition-all duration-200">
                <CardContent className="pt-6">
                  <form onSubmit={handleGithubClone} className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="project-name-github" className="text-sm font-medium flex items-center">
                        <i className="ri-edit-line text-primary mr-2"></i>
                        Project Name
                      </Label>
                      <div className="relative">
                        <Input
                          id="project-name-github"
                          placeholder="My Awesome Project"
                          value={projectName}
                          onChange={(e) => setProjectName(e.target.value)}
                          required
                          className="pl-10 border-gray-300 focus:border-primary focus:ring-1 focus:ring-primary"
                        />
                        <div className="absolute left-3 top-2.5 text-gray-400">
                          <i className="ri-code-box-line"></i>
                        </div>
                      </div>
                      <p className="text-xs text-gray-500 ml-1">
                        Choose a name that describes your project clearly
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="github-url" className="text-sm font-medium flex items-center">
                        <i className="ri-github-fill text-primary mr-2"></i>
                        GitHub Repository URL
                      </Label>
                      <div className="relative">
                        <Input
                          id="github-url"
                          placeholder="https://github.com/username/repository"
                          value={githubUrl}
                          onChange={(e) => setGithubUrl(e.target.value)}
                          required
                          className="pl-10 border-gray-300 focus:border-primary focus:ring-1 focus:ring-primary"
                        />
                        <div className="absolute left-3 top-2.5 text-gray-400">
                          <i className="ri-github-line"></i>
                        </div>
                      </div>
                      <div className="bg-gray-50 rounded-md p-4 mt-4 border border-gray-200">
                        <div className="flex items-start">
                          <i className="ri-information-line text-primary mr-2 mt-0.5"></i>
                          <div>
                            <p className="text-sm text-gray-700 font-medium mb-1">Repository Requirements</p>
                            <ul className="text-xs text-gray-600 space-y-1 list-disc pl-5">
                              <li>Repository must be public</li>
                              <li>URLs should follow the format: https://github.com/username/repository</li>
                              <li>Repository should contain code files (not just assets or documentation)</li>
                              <li>Maximum repository size: 100MB</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-700 text-white transition-all duration-200 font-medium py-6"
                      disabled={isUploading}
                    >
                      {isUploading ? (
                        <>
                          <i className="ri-loader-4-line animate-spin mr-2"></i>
                          Importing repository...
                        </>
                      ) : (
                        <>
                          <i className="ri-github-fill mr-2"></i>
                          Import from GitHub and Continue
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}