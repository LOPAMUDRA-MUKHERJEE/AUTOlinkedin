import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import UploadPage from "@/pages/upload-page";
import AnalyzePage from "@/pages/analyze-page";
import GeneratePage from "@/pages/generate-page";
import { ProtectedRoute } from "./lib/protected-route";
import { AuthProvider, useAuth } from "./hooks/use-auth";
import Toast from "./components/Toast";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={HomePage} />
      <ProtectedRoute path="/upload" component={UploadPage} />
      <Route path="/analyze/:projectId">
        {params => 
          <ProtectedRoute 
            path="/analyze/:projectId" 
            component={() => <AnalyzePage projectId={params.projectId} />} 
          />
        }
      </Route>
      <Route path="/generate/:projectId">
        {params => 
          <ProtectedRoute 
            path="/generate/:projectId" 
            component={() => <GeneratePage projectId={params.projectId} />} 
          />
        }
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
