import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ProjectDetails } from "@/types/project";

type Tone = "professional" | "casual" | "technical" | "enthusiastic";
type Length = "standard" | "in-depth";
type Audience = "recruiters" | "peers" | "professors" | "industry";

type ProjectAnalysisProps = {
  projectDetails: ProjectDetails | null;
  isLoading: boolean;
  onGeneratePost: (preferences: {
    tone: Tone;
    length: Length;
    audience: Audience;
  }) => void;
};

export default function ProjectAnalysis({
  projectDetails,
  isLoading,
  onGeneratePost,
}: ProjectAnalysisProps) {
  const [selectedTone, setSelectedTone] = useState<Tone>("professional");
  const [selectedLength, setSelectedLength] = useState<Length>("standard");
  const [selectedAudience, setSelectedAudience] = useState<Audience>("recruiters");
  const { toast } = useToast();

  const generatePostMutation = useMutation({
    mutationFn: async (preferences: {
      tone: Tone;
      length: Length;
      audience: Audience;
    }) => {
      return await apiRequest("POST", "/api/projects/generate-post", {
        ...preferences,
        projectId: projectDetails?.id,
      });
    },
    onSuccess: () => {
      onGeneratePost({
        tone: selectedTone,
        length: selectedLength,
        audience: selectedAudience,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Generation failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleToneSelect = (tone: Tone) => {
    setSelectedTone(tone);
  };

  const handleLengthSelect = (length: Length) => {
    setSelectedLength(length);
  };

  const handleAudienceChange = (value: string) => {
    setSelectedAudience(value as Audience);
  };

  const handleGeneratePost = () => {
    if (!projectDetails) {
      toast({
        title: "No project selected",
        description: "Please upload a project first",
        variant: "destructive",
      });
      return;
    }

    generatePostMutation.mutate({
      tone: selectedTone,
      length: selectedLength,
      audience: selectedAudience,
    });
  };

  return (
    <div className="lg:col-span-1 bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-semibold text-secondary-600 mb-4 flex items-center">
        <i className="ri-file-search-line mr-2 text-primary"></i>
        Project Analysis
      </h3>

      {/* Project details */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <h4 className="font-medium text-secondary-600">Project Details</h4>
          {projectDetails ? (
            <span className="text-xs bg-success-500 text-white px-2 py-1 rounded-full">
              Analyzed
            </span>
          ) : (
            <span className="text-xs bg-neutral-300 text-secondary-500 px-2 py-1 rounded-full">
              {isLoading ? "Analyzing..." : "Not uploaded"}
            </span>
          )}
        </div>

        <div className="border border-neutral-200 rounded-md p-4">
          {projectDetails ? (
            <>
              <div className="mb-3">
                <label className="block text-xs font-medium text-secondary-500 mb-1">
                  Project Name
                </label>
                <div className="font-medium text-secondary-600">
                  {projectDetails.name}
                </div>
              </div>

              <div className="mb-3">
                <label className="block text-xs font-medium text-secondary-500 mb-1">
                  Tech Stack
                </label>
                <div className="flex flex-wrap gap-2">
                  {projectDetails.techStack.map((tech, index) => (
                    <Badge
                      key={index}
                      variant="outline"
                      className="bg-neutral-100 text-xs font-medium"
                    >
                      {tech}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-secondary-500 mb-1">
                  Key Features
                </label>
                <ul className="text-sm text-secondary-600 list-disc pl-5">
                  {projectDetails.keyFeatures.map((feature, index) => (
                    <li key={index}>{feature}</li>
                  ))}
                </ul>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <div className="w-12 h-12 rounded-full bg-neutral-100 flex items-center justify-center mb-3">
                <i className="ri-folder-upload-line text-secondary-500 text-xl"></i>
              </div>
              <p className="text-sm text-secondary-500">
                {isLoading
                  ? "Analyzing your project..."
                  : "Upload a project to see analysis"}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Post preferences */}
      <div>
        <h4 className="font-medium text-secondary-600 mb-3">Post Preferences</h4>

        <div className="mb-4">
          <label className="block text-sm font-medium text-secondary-500 mb-2">
            Tone
          </label>
          <div className="grid grid-cols-2 gap-3">
            <Button
              variant={selectedTone === "professional" ? "default" : "outline"}
              className={
                selectedTone === "professional"
                  ? "bg-primary-50 border border-primary text-primary hover:bg-primary-50 hover:text-primary"
                  : "bg-white hover:bg-neutral-100"
              }
              onClick={() => handleToneSelect("professional")}
            >
              Professional
            </Button>
            <Button
              variant={selectedTone === "casual" ? "default" : "outline"}
              className={
                selectedTone === "casual"
                  ? "bg-primary-50 border border-primary text-primary hover:bg-primary-50 hover:text-primary"
                  : "bg-white hover:bg-neutral-100"
              }
              onClick={() => handleToneSelect("casual")}
            >
              Casual
            </Button>
            <Button
              variant={selectedTone === "technical" ? "default" : "outline"}
              className={
                selectedTone === "technical"
                  ? "bg-primary-50 border border-primary text-primary hover:bg-primary-50 hover:text-primary"
                  : "bg-white hover:bg-neutral-100"
              }
              onClick={() => handleToneSelect("technical")}
            >
              Technical
            </Button>
            <Button
              variant={selectedTone === "enthusiastic" ? "default" : "outline"}
              className={
                selectedTone === "enthusiastic"
                  ? "bg-primary-50 border border-primary text-primary hover:bg-primary-50 hover:text-primary"
                  : "bg-white hover:bg-neutral-100"
              }
              onClick={() => handleToneSelect("enthusiastic")}
            >
              Enthusiastic
            </Button>
          </div>
        </div>

        <div className="mb-4">
          <label className="block text-sm font-medium text-secondary-500 mb-2">
            Length
          </label>
          <div className="flex space-x-3">
            <Button
              variant={selectedLength === "standard" ? "default" : "outline"}
              className={
                selectedLength === "standard"
                  ? "flex-1 bg-primary-50 border border-primary text-primary hover:bg-primary-50 hover:text-primary"
                  : "flex-1 bg-white hover:bg-neutral-100"
              }
              onClick={() => handleLengthSelect("standard")}
            >
              Standard
            </Button>
            <Button
              variant={selectedLength === "in-depth" ? "default" : "outline"}
              className={
                selectedLength === "in-depth"
                  ? "flex-1 bg-primary-50 border border-primary text-primary hover:bg-primary-50 hover:text-primary"
                  : "flex-1 bg-white hover:bg-neutral-100"
              }
              onClick={() => handleLengthSelect("in-depth")}
            >
              In-Depth
            </Button>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-secondary-500 mb-2">
            Target Audience
          </label>
          <Select onValueChange={handleAudienceChange} defaultValue="recruiters">
            <SelectTrigger className="w-full border border-neutral-200 rounded-md py-2 text-sm text-secondary-600">
              <SelectValue placeholder="Select audience" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="recruiters">Recruiters</SelectItem>
              <SelectItem value="peers">Peers</SelectItem>
              <SelectItem value="professors">Professors</SelectItem>
              <SelectItem value="industry">Industry professionals</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button
          className="w-full mt-6 bg-primary hover:bg-primary/90 text-white font-medium py-2.5 px-4 rounded-md transition duration-200 flex items-center justify-center"
          onClick={handleGeneratePost}
          disabled={generatePostMutation.isPending || !projectDetails || isLoading}
        >
          {generatePostMutation.isPending ? (
            <>
              <i className="ri-loader-4-line animate-spin mr-2"></i>
              Generating...
            </>
          ) : (
            <>
              <i className="ri-magic-line mr-2"></i>
              Generate LinkedIn Post
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
