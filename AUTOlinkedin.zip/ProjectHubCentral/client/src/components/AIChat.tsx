import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { ChatMessage, ChatResponse } from "@/types/project";

interface AIChatProps {
  projectId: string;
  currentPost: string;
  onPostUpdated: (updatedPost: string) => void;
  disabled?: boolean;
}

export default function AIChat({
  projectId,
  currentPost,
  onPostUpdated,
  disabled = false,
}: AIChatProps) {
  const { toast } = useToast();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [showChat, setShowChat] = useState(false);

  // Chat with AI mutation
  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      const res = await apiRequest("POST", "/api/projects/chat", {
        projectId,
        message,
        currentPost,
      });
      return await res.json() as ChatResponse;
    },
    onSuccess: (data) => {
      // Add AI response to messages
      const aiMessage: ChatMessage = {
        role: "assistant",
        content: data.message,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiMessage]);

      // If there are suggested changes, update the post
      if (data.suggestedChanges) {
        onPostUpdated(data.suggestedChanges);
        toast({
          title: "Post updated",
          description: "The AI assistant has updated your post with suggested changes.",
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Chat failed",
        description: "There was an error communicating with the AI assistant: " + error.message,
        variant: "destructive",
      });
      
      // Add fallback message if API fails
      const fallbackMessage: ChatMessage = {
        role: "assistant",
        content: "I'm currently unable to process your request due to API limitations. You can still manually edit your post.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, fallbackMessage]);
    },
  });

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;
    
    // Add user message to chat
    const userMessage: ChatMessage = {
      role: "user",
      content: inputMessage,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMessage]);
    
    // Send to API
    chatMutation.mutate(inputMessage);
    
    // Clear input
    setInputMessage("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!showChat) {
    return (
      <div className="text-center">
        <Button
          onClick={() => setShowChat(true)}
          variant="outline"
          disabled={disabled}
        >
          <i className="ri-robot-line mr-2"></i>
          Get AI suggestions for your post
        </Button>
      </div>
    );
  }

  return (
    <div className="border rounded-md bg-neutral-50 overflow-hidden">
      <div className="bg-primary/90 text-white py-2 px-4 flex justify-between items-center">
        <div className="flex items-center">
          <i className="ri-robot-line mr-2 text-lg"></i>
          <h3 className="font-medium">AI Assistant</h3>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="text-white hover:bg-primary/30"
          onClick={() => setShowChat(false)}
        >
          <i className="ri-close-line"></i>
        </Button>
      </div>
      
      <div className="h-60 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="text-center text-neutral-500 p-4">
            <i className="ri-robot-line text-4xl mb-2 block"></i>
            <p>Ask the AI assistant for suggestions to improve your LinkedIn post or to make specific changes.</p>
          </div>
        ) : (
          messages.map((message, index) => (
            <div
              key={index}
              className={`flex ${
                message.role === "user" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`max-w-[75%] rounded-lg p-3 ${
                  message.role === "user"
                    ? "bg-primary/10 text-secondary-700"
                    : "bg-white border text-secondary-600"
                }`}
              >
                <p className="whitespace-pre-wrap text-sm">{message.content}</p>
                <p className="text-xs mt-1 text-neutral-500">
                  {new Date(message.timestamp).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
              </div>
            </div>
          ))
        )}
        
        {chatMutation.isPending && (
          <div className="flex justify-start">
            <div className="max-w-[75%] rounded-lg p-3 bg-white border">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-neutral-400 rounded-full animate-pulse"></div>
                <div className="w-2 h-2 bg-neutral-400 rounded-full animate-pulse delay-150"></div>
                <div className="w-2 h-2 bg-neutral-400 rounded-full animate-pulse delay-300"></div>
              </div>
            </div>
          </div>
        )}
      </div>
      
      <div className="border-t p-3 flex">
        <Textarea
          placeholder="Ask the AI assistant..."
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          onKeyDown={handleKeyDown}
          className="resize-none"
          disabled={chatMutation.isPending || disabled}
        />
        <Button
          onClick={handleSendMessage}
          className="ml-2 bg-primary text-white"
          disabled={chatMutation.isPending || !inputMessage.trim() || disabled}
        >
          <i className="ri-send-plane-fill"></i>
        </Button>
      </div>
    </div>
  );
}