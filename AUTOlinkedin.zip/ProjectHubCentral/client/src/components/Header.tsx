import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";

export default function Header() {
  const [location, setLocation] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="bg-white py-4 shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="flex items-center space-x-8">
          <Link href="/" className="text-xl font-bold flex items-center">
            <i className="ri-linkedin-box-fill text-xl text-primary mr-2"></i>
            <span className="bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
              AUTOlinkedin
            </span>
          </Link>
          
          {user && (
            <nav className="hidden md:flex items-center space-x-6">
              <Link 
                href="/" 
                className={`text-sm font-medium flex items-center transition-colors duration-200 
                  ${location === "/" 
                    ? "text-primary" 
                    : "text-gray-600 hover:text-primary"
                  }`}
              >
                <i className={`ri-dashboard-line mr-1.5 ${location === "/" ? "text-primary" : "text-gray-400"}`}></i>
                Dashboard
              </Link>
              <Link 
                href="/upload" 
                className={`text-sm font-medium flex items-center transition-colors duration-200 
                  ${location === "/upload" 
                    ? "text-primary" 
                    : "text-gray-600 hover:text-primary"
                  }`}
              >
                <i className={`ri-upload-cloud-line mr-1.5 ${location === "/upload" ? "text-primary" : "text-gray-400"}`}></i>
                Upload Project
              </Link>
            </nav>
          )}
        </div>
        
        <div className="flex items-center space-x-4">
          {user ? (
            <>
              <div className="hidden md:flex items-center border rounded-full pl-3 pr-1 py-1 bg-gray-50">
                <div className="mr-3">
                  <p className="text-sm font-medium">{user.username}</p>
                  <p className="text-xs text-gray-500">{user.email}</p>
                </div>
                <div className="h-9 w-9 bg-primary/10 rounded-full flex items-center justify-center text-primary font-medium uppercase">
                  {user.username.charAt(0)}
                </div>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleLogout}
                className="border-gray-300 text-gray-700 hover:bg-gray-50 hover:text-primary hover:border-primary transition-colors duration-200"
              >
                <i className="ri-logout-box-line mr-1.5"></i>
                Logout
              </Button>
            </>
          ) : (
            <Button 
              size="sm" 
              onClick={() => setLocation("/auth")}
              className="bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-700 text-white transition-all duration-200 font-medium"
            >
              <i className="ri-login-circle-line mr-1.5"></i>
              Sign In
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}