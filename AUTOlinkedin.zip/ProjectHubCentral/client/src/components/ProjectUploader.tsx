import { useState, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { Progress } from "@/components/ui/progress";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function ProjectUploader({ onProjectUploaded }: { onProjectUploaded: (projectId: string) => void }) {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [filesProcessed, setFilesProcessed] = useState(0);
  const [githubUrl, setGithubUrl] = useState("");
  const [uploadMethod, setUploadMethod] = useState<"folder" | "github">("folder");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const uploadFileMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await fetch('/api/projects/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(errorText || 'Failed to upload project');
      }
      
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Upload successful",
        description: "Your project has been uploaded and analyzed.",
      });
      onProjectUploaded(data.projectId);
      setIsUploading(false);
      setUploadProgress(0);
      setFilesProcessed(0);
    },
    onError: (error: Error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
      setIsUploading(false);
      setUploadProgress(0);
      setFilesProcessed(0);
    },
  });

  const uploadGithubMutation = useMutation({
    mutationFn: async (url: string) => {
      const res = await apiRequest("POST", "/api/projects/github", { url });
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Repository cloned successfully",
        description: "Your GitHub project has been analyzed.",
      });
      onProjectUploaded(data.projectId);
      setIsUploading(false);
      setUploadProgress(0);
      setGithubUrl("");
    },
    onError: (error: Error) => {
      toast({
        title: "GitHub import failed",
        description: error.message,
        variant: "destructive",
      });
      setIsUploading(false);
      setUploadProgress(0);
    },
  });

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const items = e.dataTransfer.items;
    if (!items) return;
    
    // Look for directories
    for (let i = 0; i < items.length; i++) {
      const item = items[i].webkitGetAsEntry();
      if (item && item.isDirectory) {
        handleDirectoryUpload(item);
        return;
      }
    }
    
    // If no directories found, try to handle as files
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileUpload(files);
    }
  };

  const handleFileButtonClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFileUpload(e.target.files);
    }
  };

  const handleFileUpload = (files: FileList) => {
    const formData = new FormData();
    
    setIsUploading(true);
    setFilesProcessed(0);
    
    // Simulate incremental progress for UI feedback
    const totalFiles = files.length;
    const interval = setInterval(() => {
      setFilesProcessed(prev => {
        const next = prev + 1;
        if (next >= totalFiles) {
          clearInterval(interval);
        }
        return next > totalFiles ? totalFiles : next;
      });
      
      setUploadProgress(prev => {
        const next = prev + (100 / totalFiles);
        return next > 95 ? 95 : next; // Cap at 95% until server confirms
      });
    }, 100);
    
    // Add all files to form data
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i]);
    }
    
    // Add metadata
    formData.append('fileCount', files.length.toString());
    
    // Execute upload
    uploadFileMutation.mutate(formData);
  };

  const handleDirectoryUpload = async (directoryEntry: any) => {
    // This is a simplified implementation - actual directory traversal would be more complex
    setIsUploading(true);
    
    // In a real implementation, you would recursively process the directory
    // For now, we'll just simulate progress
    const simulateProgress = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 95) {
          clearInterval(simulateProgress);
          return 95;
        }
        return prev + 5;
      });
      
      setFilesProcessed(prev => prev + 3);
    }, 200);
    
    // This would need to be replaced with actual directory traversal and file collection
    setTimeout(() => {
      toast({
        title: "Directory upload",
        description: "Directory uploads are not fully supported in this version. Please use GitHub URL instead.",
      });
      clearInterval(simulateProgress);
      setIsUploading(false);
      setUploadProgress(0);
      setFilesProcessed(0);
      setUploadMethod("github");
    }, 2000);
  };

  const handleCancelUpload = () => {
    // In a real implementation, you would abort the fetch request
    uploadFileMutation.reset();
    uploadGithubMutation.reset();
    setIsUploading(false);
    setUploadProgress(0);
    setFilesProcessed(0);
  };

  const handleGithubUpload = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!githubUrl.trim()) {
      toast({
        title: "Missing GitHub URL",
        description: "Please enter a valid GitHub repository URL",
        variant: "destructive",
      });
      return;
    }
    
    // Simple validation of GitHub URL format
    if (!githubUrl.includes("github.com/")) {
      toast({
        title: "Invalid GitHub URL",
        description: "Please enter a valid GitHub repository URL",
        variant: "destructive",
      });
      return;
    }
    
    setIsUploading(true);
    setUploadProgress(10);
    
    // Simulate progress while loading
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 90) {
          clearInterval(interval);
          return 90;
        }
        return prev + 5;
      });
    }, 300);
    
    uploadGithubMutation.mutate(githubUrl);
  };

  const renderUploadContent = () => {
    if (isUploading) {
      return (
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-secondary-500">
              {uploadMethod === "folder" ? "Uploading project files..." : "Importing GitHub repository..."}
            </span>
            <span className="text-sm text-secondary-500">{Math.round(uploadProgress)}%</span>
          </div>
          <Progress value={uploadProgress} className="w-full h-2.5" />
          
          <div className="mt-4 flex justify-between items-center text-xs text-secondary-500">
            <span>
              {uploadMethod === "folder" 
                ? `${filesProcessed} files processed` 
                : "Cloning repository..."}
            </span>
            <button 
              className="text-destructive hover:underline"
              onClick={handleCancelUpload}
            >
              Cancel
            </button>
          </div>
        </div>
      );
    }
    
    return (
      <Tabs 
        defaultValue="folder" 
        className="w-full" 
        value={uploadMethod} 
        onValueChange={(v) => setUploadMethod(v as "folder" | "github")}
      >
        <TabsList className="grid grid-cols-2 mb-6">
          <TabsTrigger value="folder">File Upload</TabsTrigger>
          <TabsTrigger value="github">GitHub URL</TabsTrigger>
        </TabsList>

        <TabsContent value="folder">
          <div 
            className={`upload-area rounded-lg p-8 flex flex-col items-center justify-center text-center cursor-pointer ${isDragging ? 'active' : ''}`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={handleFileButtonClick}
          >
            <div className="mb-4 bg-primary-50 p-4 rounded-full">
              <i className="ri-upload-cloud-2-line text-4xl text-primary"></i>
            </div>
            <h4 className="font-medium text-secondary-600 mb-2">Drag & drop your project folder here</h4>
            <p className="text-sm text-secondary-500 mb-4">Or click to browse your files</p>
            <p className="text-xs text-secondary-500">Supports code files, markdown, PDF, and more</p>
            
            <input 
              type="file" 
              id="fileUpload" 
              className="hidden" 
              ref={fileInputRef}
              onChange={handleFileInputChange}
              multiple 
              // @ts-ignore - webkitdirectory is not in standard typings
              webkitdirectory="true"
              // @ts-ignore - directory is not in standard typings
              directory=""
            />
            
            <button 
              className="mt-6 bg-primary hover:bg-primary/90 text-white font-medium py-2 px-6 rounded-md transition duration-200 flex items-center"
              onClick={(e) => {
                e.stopPropagation();
                handleFileButtonClick();
              }}
            >
              <i className="ri-folder-upload-line mr-2"></i>
              Select Folder
            </button>
          </div>
          
          <div className="mt-4 text-center">
            <p className="text-sm text-secondary-500">
              Having issues with file uploads? Try the GitHub URL option instead.
            </p>
          </div>
        </TabsContent>

        <TabsContent value="github">
          <div className="border border-neutral-200 rounded-lg p-6">
            <div className="mb-4 flex flex-col items-center">
              <div className="p-3 bg-neutral-100 rounded-full mb-3">
                <i className="ri-github-fill text-2xl text-secondary-600"></i>
              </div>
              <h4 className="font-medium text-secondary-600 mb-1">Import from GitHub</h4>
              <p className="text-sm text-secondary-500 text-center">
                Enter the URL of your GitHub repository to import and analyze
              </p>
            </div>
            
            <form onSubmit={handleGithubUpload} className="mt-4">
              <div className="mb-4">
                <Input
                  type="text"
                  placeholder="https://github.com/username/repository"
                  value={githubUrl}
                  onChange={(e) => setGithubUrl(e.target.value)}
                  className="w-full"
                />
              </div>
              
              <Button 
                type="submit"
                className="w-full bg-primary hover:bg-primary/90 text-white"
                disabled={uploadGithubMutation.isPending}
              >
                <i className="ri-github-line mr-2"></i>
                Import Repository
              </Button>
            </form>
            
            <div className="mt-4 text-xs text-secondary-500">
              <p className="mb-1 font-medium">Supported repositories:</p>
              <ul className="list-disc pl-5">
                <li>Public repositories (no authentication required)</li>
                <li>Private repositories require PAT (coming soon)</li>
                <li>Repository size limited to 100MB</li>
              </ul>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
      <h3 className="text-lg font-semibold text-secondary-600 mb-4">Upload your project</h3>
      {renderUploadContent()}
    </div>
  );
}
