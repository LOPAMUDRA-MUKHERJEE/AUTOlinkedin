import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import AIChat from "./AIChat";
import { Post } from "@/types/project";

interface PostPreviewProps {
  projectId: string | null;
  post: Post | null;
  isLoading: boolean;
  onPostVersionSelect: (version: string) => void;
  onPostUpdated: (updatedPost: Post) => void;
}

export default function PostPreview({
  projectId,
  post,
  isLoading,
  onPostVersionSelect,
  onPostUpdated,
}: PostPreviewProps) {
  const [versions, setVersions] = useState<string[]>(post ? ["Version 1"] : []);
  const [selectedVersion, setSelectedVersion] = useState("Version 1");
  const { toast } = useToast();

  const copyToClipboard = () => {
    if (!post?.content) return;
    
    navigator.clipboard.writeText(post.content)
      .then(() => {
        toast({
          title: "Success!",
          description: "Your LinkedIn post has been copied to clipboard.",
        });
      })
      .catch(() => {
        toast({
          title: "Failed to copy",
          description: "Could not copy to clipboard. Please try again.",
          variant: "destructive",
        });
      });
  };

  const downloadAsText = () => {
    if (!post?.content) return;
    
    const element = document.createElement("a");
    const file = new Blob([post.content], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `linkedin-post-${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    
    toast({
      title: "Downloaded",
      description: "Your LinkedIn post has been downloaded as a text file.",
    });
  };

  const saveVersion = useMutation({
    mutationFn: async () => {
      if (!projectId || !post) {
        throw new Error("No post to save");
      }
      
      const res = await apiRequest("POST", "/api/projects/save-post-version", {
        projectId,
        postContent: post.content,
      });
      
      return await res.json();
    },
    onSuccess: (data) => {
      const newVersionLabel = `Version ${versions.length + 1}`;
      setVersions([...versions, newVersionLabel]);
      setSelectedVersion(newVersionLabel);
      
      toast({
        title: "Version saved",
        description: `Post has been saved as ${newVersionLabel}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to save version",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleVersionChange = (version: string) => {
    setSelectedVersion(version);
    onPostVersionSelect(version);
  };

  const handleChatUpdate = (updatedPost: string) => {
    if (post) {
      const updatedPostObj = { ...post, content: updatedPost };
      onPostUpdated(updatedPostObj);
    }
  };

  return (
    <div className="lg:col-span-2">
      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-secondary-600 flex items-center">
            <i className="ri-linkedin-box-fill mr-2 text-primary"></i>
            LinkedIn Post Preview
          </h3>
          
          <div className="flex items-center space-x-2">
            <Select 
              onValueChange={handleVersionChange} 
              value={selectedVersion}
              disabled={versions.length <= 1}
            >
              <SelectTrigger className="border border-neutral-200 rounded-md py-1 px-2 text-xs text-secondary-500 h-8 w-32">
                <SelectValue placeholder="Version" />
              </SelectTrigger>
              <SelectContent>
                {versions.map((version) => (
                  <SelectItem key={version} value={version} className="text-xs">
                    {version}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <button 
              className="text-primary hover:text-primary/80"
              onClick={() => saveVersion.mutate()}
              disabled={saveVersion.isPending || !post}
            >
              <i className="ri-save-line text-lg"></i>
            </button>
          </div>
        </div>
        
        {/* LinkedIn post format */}
        <div className="border border-neutral-200 rounded-lg p-4 mb-4">
          {post ? (
            <>
              {/* Profile header */}
              <div className="flex items-start mb-4">
                <div className="w-12 h-12 bg-neutral-300 rounded-full overflow-hidden mr-3 flex items-center justify-center bg-primary text-white uppercase font-medium">
                  {post.author?.charAt(0) || 'U'}
                </div>
                <div>
                  <h4 className="font-medium text-secondary-600">{post.author || 'User'}</h4>
                  <p className="text-xs text-secondary-500">{post.headline || 'LinkedIn User'}</p>
                  <div className="flex items-center text-xs text-secondary-500 mt-1">
                    <span>Just now</span>
                    <span className="mx-1">•</span>
                    <i className="ri-earth-line"></i>
                  </div>
                </div>
              </div>
              
              {/* Post content */}
              <div className="text-secondary-600 mb-4 whitespace-pre-line">
                {post.content}
              </div>
              
              {/* Post image if available */}
              {post.imageUrl && (
                <div className="mb-4 rounded-lg overflow-hidden border border-neutral-200">
                  <img src={post.imageUrl} alt="Project" className="w-full h-auto" />
                </div>
              )}
              
              {/* Engagement metrics */}
              <div className="flex items-center justify-between text-sm text-secondary-500 py-2 border-t border-b border-neutral-200">
                <div className="flex items-center">
                  <span className="flex items-center">
                    <i className="ri-thumb-up-line text-primary"></i>
                    <i className="ri-heart-3-fill text-destructive"></i>
                    <span className="ml-1">0</span>
                  </span>
                </div>
                <div className="flex items-center space-x-4">
                  <span>0 comments</span>
                  <span>0 reposts</span>
                </div>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center py-12">
              {isLoading ? (
                <>
                  <div className="w-12 h-12 rounded-full bg-neutral-100 flex items-center justify-center mb-3">
                    <i className="ri-loader-4-line animate-spin text-primary text-xl"></i>
                  </div>
                  <p className="text-sm text-secondary-500">Generating LinkedIn post...</p>
                </>
              ) : (
                <>
                  <div className="w-12 h-12 rounded-full bg-neutral-100 flex items-center justify-center mb-3">
                    <i className="ri-linkedin-box-line text-secondary-500 text-xl"></i>
                  </div>
                  <p className="text-sm text-secondary-500">Generate a post to preview it here</p>
                </>
              )}
            </div>
          )}
        </div>
        
        {/* Action buttons */}
        <div className="flex flex-wrap gap-3">
          <Button
            className="flex-1 bg-primary hover:bg-primary/90 text-white font-medium py-2 px-4 rounded-md transition duration-200 flex items-center justify-center"
            onClick={copyToClipboard}
            disabled={!post}
          >
            <i className="ri-clipboard-line mr-2"></i>
            Copy to Clipboard
          </Button>
          <Button
            variant="outline"
            className="flex-1 border border-primary text-primary hover:bg-primary-50 font-medium py-2 px-4 rounded-md transition duration-200 flex items-center justify-center"
            onClick={downloadAsText}
            disabled={!post}
          >
            <i className="ri-download-line mr-2"></i>
            Download as Text
          </Button>
          <Button
            variant="outline"
            className="flex-1 border border-neutral-200 text-secondary-500 hover:bg-neutral-100 font-medium py-2 px-4 rounded-md transition duration-200 flex items-center justify-center"
            onClick={() => saveVersion.mutate()}
            disabled={saveVersion.isPending || !post}
          >
            {saveVersion.isPending ? (
              <>
                <i className="ri-loader-4-line animate-spin mr-2"></i>
                Saving...
              </>
            ) : (
              <>
                <i className="ri-save-line mr-2"></i>
                Save Version
              </>
            )}
          </Button>
        </div>
      </div>
      
      {/* AI Chat Component */}
      <AIChat 
        projectId={projectId} 
        currentPost={post?.content || ""} 
        onPostUpdated={handleChatUpdate}
        disabled={!post}
      />
    </div>
  );
}
