import { Link } from "wouter";

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="py-10 bg-gray-50 border-t">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <Link 
              href="/" 
              className="flex items-center mb-4"
            >
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-purple-600 rounded-lg flex items-center justify-center mr-2">
                <i className="ri-linkedin-box-fill text-sm text-white"></i>
              </div>
              <span className="text-lg font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
                AUTOlinkedin
              </span>
            </Link>
            <p className="text-sm text-gray-600 mb-4 max-w-xs">
              Showcase your coding projects with AI-generated LinkedIn posts that highlight your technical skills and achievements.
            </p>
            <div className="flex space-x-3">
              <a 
                href="#" 
                className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center text-gray-600 hover:bg-primary hover:text-white transition-colors duration-200"
              >
                <i className="ri-linkedin-fill text-sm"></i>
              </a>
              <a 
                href="#" 
                className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center text-gray-600 hover:bg-primary hover:text-white transition-colors duration-200"
              >
                <i className="ri-github-fill text-sm"></i>
              </a>
              <a 
                href="#" 
                className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center text-gray-600 hover:bg-primary hover:text-white transition-colors duration-200"
              >
                <i className="ri-twitter-fill text-sm"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold text-gray-800 mb-4">Navigation</h3>
            <div className="flex flex-col space-y-2">
              <Link 
                href="/" 
                className="text-sm text-gray-600 hover:text-primary transition-colors duration-200 flex items-center"
              >
                <i className="ri-home-4-line mr-2"></i>
                Home
              </Link>
              <Link 
                href="/upload" 
                className="text-sm text-gray-600 hover:text-primary transition-colors duration-200 flex items-center"
              >
                <i className="ri-upload-cloud-line mr-2"></i>
                Upload Project
              </Link>
              <Link 
                href="/auth" 
                className="text-sm text-gray-600 hover:text-primary transition-colors duration-200 flex items-center"
              >
                <i className="ri-login-circle-line mr-2"></i>
                Sign In
              </Link>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold text-gray-800 mb-4">Resources</h3>
            <div className="flex flex-col space-y-2">
              <a
                href="#"
                className="text-sm text-gray-600 hover:text-primary transition-colors duration-200 flex items-center"
              >
                <i className="ri-github-fill mr-2"></i>
                GitHub Repository
              </a>
              <a
                href="#"
                className="text-sm text-gray-600 hover:text-primary transition-colors duration-200 flex items-center"
              >
                <i className="ri-question-line mr-2"></i>
                Help & Support
              </a>
              <a
                href="#"
                className="text-sm text-gray-600 hover:text-primary transition-colors duration-200 flex items-center"
              >
                <i className="ri-file-list-3-line mr-2"></i>
                Documentation
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t mt-8 pt-6 flex flex-col md:flex-row justify-between items-center text-sm text-gray-500">
          <p>© {currentYear} AUTOlinkedin. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-primary transition-colors duration-200">Privacy Policy</a>
            <a href="#" className="hover:text-primary transition-colors duration-200">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}