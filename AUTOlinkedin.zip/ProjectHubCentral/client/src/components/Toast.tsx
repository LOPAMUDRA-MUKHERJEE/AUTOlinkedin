import { useEffect, useState } from "react";

interface ToastProps {
  id?: string;
  type?: "success" | "error" | "info";
  message: string;
  duration?: number;
  onClose?: () => void;
}

export default function Toast({ 
  type = "info", 
  message, 
  duration = 5000, 
  onClose 
}: ToastProps) {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
      if (onClose) onClose();
    }, duration);

    return () => clearTimeout(timer);
  }, [duration, onClose]);

  if (!visible) return null;

  const bgColor = 
    type === "success" ? "bg-success-50 border-success-200" :
    type === "error" ? "bg-red-50 border-red-200" :
    "bg-blue-50 border-blue-200";

  const textColor = 
    type === "success" ? "text-success-700" :
    type === "error" ? "text-red-700" :
    "text-blue-700";

  const icon = 
    type === "success" ? "ri-checkbox-circle-fill" :
    type === "error" ? "ri-error-warning-fill" :
    "ri-information-fill";

  return (
    <div className="fixed bottom-4 right-4 z-50 animate-fade-in">
      <div className={`rounded-md border ${bgColor} py-3 px-4 flex items-start max-w-sm shadow-md`}>
        <i className={`${icon} ${textColor} text-lg mt-0.5 mr-3`}></i>
        <div>
          <p className={`${textColor} font-medium text-sm`}>{message}</p>
        </div>
        <button 
          className="ml-4 text-neutral-400 hover:text-neutral-600"
          onClick={() => {
            setVisible(false);
            if (onClose) onClose();
          }}
        >
          <i className="ri-close-line"></i>
        </button>
      </div>
    </div>
  );
}