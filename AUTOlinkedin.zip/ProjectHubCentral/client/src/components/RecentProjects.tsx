import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";

// Define Project interface locally
interface Project {
  id: string;
  name: string;
  description?: string;
  userId: number;
  repoUrl?: string;
  createdAt: Date | string;
  techStack?: string[];
  keyFeatures?: string[];
  fileCount?: number;
  primaryLanguage?: string;
}

// Define a local formatDate function similar to the shared one
function formatDate(date: Date | string | undefined): string {
  if (!date) return "Unknown date";
  
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

interface RecentProjectsProps {
  onSelectProject: (projectId: string) => void;
}

export default function RecentProjects({ onSelectProject }: RecentProjectsProps) {
  // Fetch recent projects
  const { data: projects, isLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects/recent"],
  });

  if (isLoading) {
    return (
      <div className="border rounded-lg p-8 flex items-center justify-center">
        <div className="flex items-center space-x-3">
          <div className="w-4 h-4 border-2 border-t-primary border-neutral-200 rounded-full animate-spin"></div>
          <p className="text-neutral-500">Loading recent projects...</p>
        </div>
      </div>
    );
  }

  if (!projects || projects.length === 0) {
    return (
      <div className="border rounded-lg p-8 text-center">
        <div className="w-16 h-16 mx-auto bg-neutral-100 rounded-full flex items-center justify-center mb-4">
          <i className="ri-folder-line text-3xl text-neutral-400"></i>
        </div>
        <h3 className="text-lg font-medium text-secondary-600 mb-2">No projects yet</h3>
        <p className="text-neutral-500 mb-6">
          Upload your first project to get started.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {projects.map((project) => (
        <div
          key={project.id}
          className="border rounded-lg overflow-hidden bg-white shadow-sm hover:shadow-md transition-shadow"
        >
          <div className="p-4">
            <div className="flex justify-between items-start mb-2">
              <h3 className="font-medium text-secondary-600 truncate">{project.name}</h3>
              <span className="text-xs text-neutral-500">
                {formatDate(project.createdAt)}
              </span>
            </div>
            
            {project.description && (
              <p className="text-sm text-neutral-600 line-clamp-2 mb-3">
                {project.description}
              </p>
            )}
            
            {project.primaryLanguage && (
              <div className="flex items-center text-xs text-neutral-500 mb-3">
                <i className="ri-code-line mr-1"></i>
                <span>{project.primaryLanguage}</span>
                {project.fileCount && (
                  <span className="ml-3">
                    <i className="ri-file-line mr-1"></i>
                    {project.fileCount} files
                  </span>
                )}
              </div>
            )}
            
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full" 
              onClick={() => onSelectProject(project.id)}
            >
              <i className="ri-eye-line mr-2"></i>
              View Project
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}